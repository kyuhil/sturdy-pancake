-- Hearthpad: device layer — reads the controller's mapped state for visual feedback
-- (button presses, trigger layers, stick scrolling) and drives haptics.
-- Input *actions* never go through here; they go through bindings, which stay secure.
local _, HP = ...
local G = HP:NewModule("Gamepad")

local GP = C_GamePad
local indexToName = {}
local down = {}
local sticks = { { x = 0, y = 0 }, { x = 0, y = 0 } }
local listeners = 0

function G:IsAvailable()
	return GP and GP.IsEnabled and GP.IsEnabled() or false
end

function G:IsDown(name) return down[name] == true end
function G:Stick(i) return sticks[i] end

-- C_GamePad.ButtonIndexToBinding may be 0- or 1-based depending on build; detect once.
local function buildIndexMap(count)
	wipe(indexToName)
	if not (GP and GP.ButtonIndexToBinding) then return end
	local zeroOk = pcall(GP.ButtonIndexToBinding, 0) and GP.ButtonIndexToBinding(0)
	local offset = zeroOk and -1 or 0
	for i = 1, count do
		local ok, name = pcall(GP.ButtonIndexToBinding, i + offset)
		if ok and name then indexToName[i] = name end
	end
end

local poller = CreateFrame("Frame")
poller:Hide()
local acc = 0
poller:SetScript("OnUpdate", function(_, elapsed)
	acc = acc + elapsed
	if acc < 1 / 60 then return end
	acc = 0
	if not (GP and GP.GetActiveDeviceID and GP.GetDeviceMappedState) then return end
	local id = GP.GetActiveDeviceID()
	if not id then return end
	local ok, state = pcall(GP.GetDeviceMappedState, id)
	if not ok or not state then return end

	local buttons = state.buttons
	if buttons then
		if #indexToName ~= #buttons then buildIndexMap(#buttons) end
		for i = 1, #buttons do
			local name = indexToName[i]
			if name then
				local isDown = buttons[i] and true or false
				if isDown ~= (down[name] or false) then
					down[name] = isDown
					HP:Fire(isDown and "HP_PAD_DOWN" or "HP_PAD_UP", name)
				end
			end
		end
	end
	if state.sticks then
		for i = 1, 2 do
			local s = state.sticks[i]
			if s then
				sticks[i].x, sticks[i].y = s.x or 0, s.y or 0
			end
		end
		HP:Fire("HP_STICKS", sticks)
	end
end)

-- Modules that need live pad state call Acquire/Release so we only poll when useful.
function G:Acquire() listeners = listeners + 1 poller:Show() end
function G:Release()
	listeners = math.max(0, listeners - 1)
	if listeners == 0 then poller:Hide() end
end

---------------------------------------------------------------------------
-- Haptics. Through Steam Input the Deck reports as an XInput pad, so rumble
-- is forwarded to its haptic motors. Patterns are short to stay readable.
---------------------------------------------------------------------------
local patterns = {
	tick   = { { "High", 0.25, 0.04 } },
	light  = { { "High", 0.45, 0.07 } },
	medium = { { "Low", 0.6, 0.12 } },
	heavy  = { { "Low", 1.0, 0.22 } },
	heartbeat = { { "Low", 0.7, 0.08 }, { "pause", 0, 0.10 }, { "Low", 0.45, 0.08 } },
	levelup = { { "High", 0.5, 0.08 }, { "pause", 0, 0.06 }, { "High", 0.7, 0.08 }, { "pause", 0, 0.06 }, { "Low", 0.9, 0.2 } },
}

local playing = 0
function G:Rumble(name)
	if not (HP.db and HP.db.haptics.enabled) then return end
	if not (GP and GP.SetVibration) then return end
	local seq = patterns[name]
	if not seq then return end
	playing = playing + 1
	local token = playing
	local strength = HP.db.haptics.strength or 1
	local t = 0
	for _, step in ipairs(seq) do
		local kind, power, dur = step[1], step[2], step[3]
		C_Timer.After(t, function()
			if token ~= playing then return end
			if kind == "pause" then pcall(GP.StopVibration)
			else pcall(GP.SetVibration, kind, power * strength) end
		end)
		t = t + dur
	end
	C_Timer.After(t, function() if token == playing then pcall(GP.StopVibration) end end)
end

function G:Init()
	HP:RegisterOption({ path = "haptics.enabled", label = "Haptic feedback", section = "Feel", type = "toggle" })
	HP:RegisterOption({ path = "haptics.strength", label = "Haptic strength", section = "Feel", type = "range", min = 0.2, max = 1, step = 0.1 })
	HP:RegisterOption({ path = "haptics.onCast", label = "Tick on every cast", section = "Feel", type = "toggle" })
end
