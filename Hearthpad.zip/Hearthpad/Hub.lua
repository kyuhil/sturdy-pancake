-- Hearthpad: the Hub — what the Menu (Start) button opens. A big-tile journey menu for every
-- window you need on the road, and a fully controller-driven Settings page generated from
-- every option the modules register. L1/R1 switch pages, B or Menu closes.
local _, HP = ...
local H = HP:NewModule("Hub")
local T = HP.Theme
local I

local COLS, TILE_W, TILE_H, GAP = 4, 196, 112, 12
local ROWS_VISIBLE = 10

local root, frame, tabs, grid, settings, header, hints
local tiles, rows = {}, {}
local page = "journey"
local tileSel, rowSel, rowOffset = 1, 1, 0
local flatOptions = {}
local ctx = { name = "hub", passthrough = { PADBACK = true } }

local function clickFirst(...)
	for i = 1, select("#", ...) do
		local b = _G[select(i, ...)]
		if b and b.Click and b:IsShown() then pcall(b.Click, b) return true end
	end
end

local function callFirst(...)
	for i = 1, select("#", ...) do
		local fn = select(i, ...)
		if type(fn) == "function" and pcall(fn) then return true end
	end
end

H.tiles = {
	{ label = "Character", icon = "Interface\\Icons\\INV_Chest_Cloth_17", run = function()
		return clickFirst("CharacterMicroButton") or callFirst(function() ToggleCharacter("PaperDollFrame") end) end },
	{ label = "Bags", icon = "Interface\\Icons\\INV_Misc_Bag_10", run = function() callFirst(ToggleAllBags, OpenAllBags) end },
	{ label = "Spellbook", icon = "Interface\\Icons\\INV_Misc_Book_09", run = function()
		return clickFirst("PlayerSpellsMicroButton", "SpellbookMicroButton")
			or callFirst(function() PlayerSpellsUtil.ToggleSpellBookFrame() end, function() ToggleSpellBook(BOOKTYPE_SPELL or "spell") end) end },
	{ label = "Talents", icon = "Interface\\Icons\\Ability_Marksmanship", run = function()
		return callFirst(function() PlayerSpellsUtil.ToggleClassTalentFrame() end, ToggleTalentFrame)
			or clickFirst("TalentMicroButton", "PlayerSpellsMicroButton") end },
	{ label = "Quest Log", icon = "Interface\\Icons\\INV_Misc_Note_01", run = function()
		return callFirst(ToggleQuestLog) or clickFirst("QuestLogMicroButton") end },
	{ label = "World Map", icon = "Interface\\Icons\\INV_Misc_Map_01", run = function() callFirst(ToggleWorldMap) end },
	{ label = "Social", icon = "Interface\\Icons\\INV_Letter_15", run = function()
		return callFirst(ToggleFriendsFrame) or clickFirst("SocialsMicroButton", "GuildMicroButton") end },
	{ label = "Group Finder", icon = "Interface\\Icons\\INV_Misc_GroupNeedMore", run = function()
		return callFirst(PVEFrame_ToggleFrame) or clickFirst("LFDMicroButton", "LFGMicroButton") end },
	{ label = "Collections", icon = "Interface\\Icons\\Ability_Mount_RidingHorse", run = function()
		return callFirst(ToggleCollectionsJournal) or clickFirst("CollectionsMicroButton") end },
	{ label = "Camera", icon = "Interface\\Icons\\INV_Misc_Spyglass_03", keepOpen = true, run = function() HP.Explore:CycleCamera() end,
		sub = function() local m = HP.Explore.cameraModes[HP.db.explore.cameraMode] return m and m.label end },
	{ label = "Controls", icon = "Interface\\Icons\\Trade_Engineering", run = function() HP.Onboarding:ShowControls() end },
	{ label = "Game Menu", icon = "Interface\\Icons\\INV_Misc_Rune_01", run = function() callFirst(ToggleGameMenu) end },
}

---------------------------------------------------------------------------
-- Construction
---------------------------------------------------------------------------
local function buildTile(i, def)
	local t = CreateFrame("Frame", nil, grid, "BackdropTemplate")
	t:SetSize(TILE_W, TILE_H)
	t:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 2 })
	local col, row = (i - 1) % COLS, math.floor((i - 1) / COLS)
	t:SetPoint("TOPLEFT", col * (TILE_W + GAP), -row * (TILE_H + GAP))
	t.icon = t:CreateTexture(nil, "ARTWORK")
	t.icon:SetSize(52, 52)
	t.icon:SetPoint("TOP", 0, -14)
	t.icon:SetTexture(def.icon)
	t.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	t.label = T.Text(t, 17, T.color.text)
	t.label:SetPoint("TOP", t.icon, "BOTTOM", 0, -8)
	t.label:SetText(def.label)
	t.sub = T.Text(t, 12, T.color.dim)
	t.sub:SetPoint("TOP", t.label, "BOTTOM", 0, -2)
	t.def = def
	return t
end

local function buildRow(i)
	local r = CreateFrame("Frame", nil, settings)
	r:SetSize(820, 34)
	r:SetPoint("TOPLEFT", 0, -(i - 1) * 36)
	r.bg = r:CreateTexture(nil, "BACKGROUND")
	r.bg:SetAllPoints()
	r.label = T.Text(r, 16, T.color.text)
	r.label:SetPoint("LEFT", 14, 0)
	r.value = T.Text(r, 16, T.color.accent)
	r.value:SetPoint("RIGHT", -16, 0)
	r.bar = r:CreateTexture(nil, "ARTWORK")
	r.bar:SetPoint("TOPLEFT") r.bar:SetPoint("BOTTOMLEFT") r.bar:SetWidth(3)
	r.bar:SetColorTexture(unpack(T.color.accent))
	return r
end

local function build()
	root = CreateFrame("Frame", "HearthpadHub", UIParent)
	root:SetAllPoints(UIParent)
	root:SetFrameStrata("DIALOG")
	root:EnableMouse(true)
	local dim = root:CreateTexture(nil, "BACKGROUND")
	dim:SetAllPoints()
	dim:SetColorTexture(0, 0, 0, 0.62)
	root:Hide()

	frame = T.Panel(root, nil)
	frame:SetSize(COLS * (TILE_W + GAP) + 40, 3 * (TILE_H + GAP) + 170)
	frame:SetPoint("CENTER")

	local title = T.Text(frame, 28, T.color.accent, "OUTLINE")
	title:SetPoint("TOPLEFT", 22, -18)
	title:SetText("Hearthpad")
	header = T.Text(frame, 14, T.color.dim)
	header:SetPoint("TOPRIGHT", -22, -24)

	tabs = {}
	local lb = T.Glyph(frame, "PADLSHOULDER", 24)
	lb:SetPoint("TOPLEFT", 22, -62)
	local x = 54
	for i, def in ipairs({ { "journey", "Journey" }, { "settings", "Settings" } }) do
		local fs = T.Text(frame, 19, T.color.text)
		fs:SetPoint("TOPLEFT", x, -64)
		fs:SetText(def[2])
		fs.id = def[1]
		tabs[i] = fs
		x = x + fs:GetStringWidth() + 28
	end
	local rb = T.Glyph(frame, "PADRSHOULDER", 24)
	rb:SetPoint("TOPLEFT", x - 10, -62)

	grid = CreateFrame("Frame", nil, frame)
	grid:SetPoint("TOPLEFT", 20, -104)
	grid:SetSize(COLS * (TILE_W + GAP), 3 * (TILE_H + GAP))
	for i, def in ipairs(H.tiles) do tiles[i] = buildTile(i, def) end

	settings = CreateFrame("Frame", nil, frame)
	settings:SetPoint("TOPLEFT", 20, -104)
	settings:SetSize(820, ROWS_VISIBLE * 36)
	for i = 1, ROWS_VISIBLE do rows[i] = buildRow(i) end
	settings.desc = T.Text(frame, 14, T.color.dim)
	settings.desc:SetPoint("BOTTOMLEFT", 24, 52)
	settings.desc:SetWidth(820)
	settings.desc:SetJustifyH("LEFT")

	hints = T.HintBar(frame, nil, 26)
	hints:SetPoint("BOTTOMLEFT", 22, 14)
end

---------------------------------------------------------------------------
-- Settings model
---------------------------------------------------------------------------
local function rebuildOptions()
	wipe(flatOptions)
	local order, bySection = {}, {}
	for _, opt in ipairs(HP.options) do
		if not bySection[opt.section] then bySection[opt.section] = {} order[#order + 1] = opt.section end
		table.insert(bySection[opt.section], opt)
	end
	for _, section in ipairs(order) do
		flatOptions[#flatOptions + 1] = { header = section }
		for _, opt in ipairs(bySection[section]) do flatOptions[#flatOptions + 1] = opt end
	end
end

local function valueText(opt)
	local v = HP:Get(opt.path)
	if opt.type == "toggle" then return v and "On" or "|cff888888Off|r" end
	if opt.type == "choice" then
		for _, pair in ipairs(opt.values) do if pair[1] == v then return "<  " .. pair[2] .. "  >" end end
		return tostring(v)
	end
	if opt.type == "range" then
		local pct = (v - opt.min) / (opt.max - opt.min)
		local filled = math.floor(pct * 10 + 0.5)
		return ("%s  |cffffd060%s|r|cff444444%s|r"):format(
			(opt.step or 1) < 1 and ("%.2f"):format(v) or tostring(math.floor(v + 0.5)),
			("|"):rep(filled * 2), ("|"):rep((10 - filled) * 2))
	end
	return tostring(v)
end

local function changeOption(opt, dir)
	local v = HP:Get(opt.path)
	if opt.type == "toggle" then HP:Set(opt.path, not v)
	elseif opt.type == "choice" then
		local idx = 1
		for i, pair in ipairs(opt.values) do if pair[1] == v then idx = i end end
		idx = (idx - 1 + (dir or 1)) % #opt.values + 1
		HP:Set(opt.path, opt.values[idx][1])
	elseif opt.type == "range" then
		local step = opt.step or 1
		local nv = HP.Clamp((v or opt.min) + step * (dir or 1), opt.min, opt.max)
		nv = math.floor(nv / step + 0.5) * step
		HP:Set(opt.path, nv)
	end
	HP.Gamepad:Rumble("tick")
end

local function moveRow(dir)
	local n = #flatOptions
	local i = rowSel
	repeat
		i = i + dir
	until i < 1 or i > n or not flatOptions[i].header
	if i >= 1 and i <= n then rowSel = i end
	if rowSel <= rowOffset then rowOffset = math.max(0, rowSel - 2) end
	if rowSel > rowOffset + ROWS_VISIBLE then rowOffset = rowSel - ROWS_VISIBLE end
end

---------------------------------------------------------------------------
-- Rendering
---------------------------------------------------------------------------
function H:Render()
	for _, fs in ipairs(tabs) do
		local on = fs.id == page
		local c = on and T.color.accent or T.color.dim
		fs:SetTextColor(c[1], c[2], c[3])
	end
	local money = GetMoney and GetCoinTextureString(GetMoney()) or ""
	header:SetText(("%s · Level %d · %s   %s"):format(UnitName("player"), UnitLevel("player"), GetZoneText() or "", money))

	grid:SetShown(page == "journey")
	settings:SetShown(page == "settings")
	settings.desc:SetShown(page == "settings")

	if page == "journey" then
		for i, t in ipairs(tiles) do
			local sel = i == tileSel
			t:SetBackdropColor(sel and 0.14 or 0.06, sel and 0.12 or 0.065, sel and 0.06 or 0.08, 0.95)
			t:SetBackdropBorderColor(1, 0.82, 0.38, sel and 0.95 or 0.08)
			t.icon:SetDesaturated(not sel)
			t.sub:SetText(t.def.sub and t.def.sub() or "")
		end
		hints:SetHints({ { "PAD1", "Open" }, { "PAD2", "Close" }, { "PADRSHOULDER", "Settings" } })
	else
		for i, r in ipairs(rows) do
			local opt = flatOptions[rowOffset + i]
			if not opt then r:Hide()
			else
				r:Show()
				local sel = (rowOffset + i) == rowSel
				if opt.header then
					r.label:SetText(opt.header:upper())
					r.label:SetTextColor(unpack(T.color.accent))
					r.value:SetText("")
					r.bg:SetColorTexture(0, 0, 0, 0)
					r.bar:Hide()
				else
					r.label:SetText(opt.label)
					r.label:SetTextColor(unpack(T.color.text))
					r.value:SetText(valueText(opt))
					r.bg:SetColorTexture(sel and 0.16 or 0.05, sel and 0.13 or 0.05, sel and 0.06 or 0.06, sel and 0.9 or 0.5)
					r.bar:SetShown(sel)
				end
			end
		end
		local cur = flatOptions[rowSel]
		settings.desc:SetText(cur and cur.desc or "")
		local list = { { "PADDUP", "Select" } }
		if cur and cur.type == "toggle" then list[#list + 1] = { "PAD1", "Toggle" }
		else list[#list + 1] = { "PADDLEFT", "Adjust" } end
		list[#list + 1] = { "PAD2", "Close" }
		list[#list + 1] = { "PADLSHOULDER", "Journey" }
		hints:SetHints(list)
	end
end

---------------------------------------------------------------------------
-- Input
---------------------------------------------------------------------------
function ctx:OnKey(key)
	if key == "PAD2" or key == "PADFORWARD" then H:Hide() return end
	if key == "PADLSHOULDER" or key == "PADRSHOULDER" then
		page = (page == "journey") and "settings" or "journey"
		HP.Gamepad:Rumble("tick")
		H:Render()
		return
	end
	if page == "journey" then
		local n = #tiles
		local nextSel = tileSel
		if key == "PADDRIGHT" then nextSel = tileSel % n + 1
		elseif key == "PADDLEFT" then nextSel = (tileSel - 2) % n + 1
		elseif key == "PADDDOWN" then nextSel = tileSel + COLS if nextSel > n then nextSel = (tileSel - 1) % COLS + 1 end
		elseif key == "PADDUP" then nextSel = tileSel - COLS if nextSel < 1 then nextSel = tileSel + COLS * math.floor((n - tileSel) / COLS) end
		elseif key == "PAD1" then
			local def = tiles[tileSel].def
			HP.Gamepad:Rumble("light")
			if not def.keepOpen then H:Hide() end
			C_Timer.After(0, function() pcall(def.run) H:Render() end)
			return
		end
		if nextSel ~= tileSel then tileSel = nextSel HP.Gamepad:Rumble("tick") end
	else
		local opt = flatOptions[rowSel]
		if key == "PADDDOWN" then moveRow(1) HP.Gamepad:Rumble("tick")
		elseif key == "PADDUP" then moveRow(-1) HP.Gamepad:Rumble("tick")
		elseif opt and not opt.header then
			if key == "PADDRIGHT" then changeOption(opt, 1)
			elseif key == "PADDLEFT" then changeOption(opt, -1)
			elseif key == "PAD1" then changeOption(opt, 1) end
		end
	end
	H:Render()
end

function ctx:OnCombat() H:Hide() end

function H:Show()
	if InCombatLockdown() then
		HP:Toast("The Hub opens after combat · L2 + Menu for the game menu", T.color.danger)
		return
	end
	if not I:Push(ctx) then return end
	rebuildOptions()
	if not flatOptions[rowSel] or flatOptions[rowSel].header then rowSel = 1 moveRow(1) end
	root:Show()
	self:Render()
	PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPEN or 850)
end

function H:Hide()
	if not root:IsShown() then return end
	root:Hide()
	I:Pop(ctx)
	PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_CLOSE or 851)
end

function H:Toggle()
	if root and root:IsShown() then self:Hide() else self:Show() end
end

function H:Init()
	I = HP.Input
	build()
	HP:On("HP_SETTING_CHANGED", function() if root:IsShown() then H:Render() end end)

	-- A small page in Blizzard's own Settings so the addon is discoverable there too.
	if Settings and Settings.RegisterCanvasLayoutCategory then
		local canvas = CreateFrame("Frame")
		local t = T.Text(canvas, 16, T.color.text)
		t:SetPoint("TOPLEFT", 16, -16)
		t:SetWidth(560)
		t:SetJustifyH("LEFT")
		t:SetText("Hearthpad is configured from its own controller menu.\n\nPress the Menu button, or type /hp, then use R1 to reach Settings.")
		pcall(function()
			local cat = Settings.RegisterCanvasLayoutCategory(canvas, "Hearthpad")
			Settings.RegisterAddOnCategory(cat)
		end)
	end
end
