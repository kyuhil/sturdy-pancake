-- Hearthpad: the crossbar control scheme.
-- Triggers are modifiers (L2 = Shift, R2 = Ctrl, both = Ctrl+Shift), giving four layers
-- of 8 slots on the face buttons and D-pad. The layout is applied as non-priority override
-- bindings on Blizzard's own action buttons, so cooldowns, procs, stance paging and
-- combat all keep working natively and securely. Your saved key bindings are never edited.
local _, HP = ...
local B = HP:NewModule("Bindings")

local owner = CreateFrame("Frame", "HearthpadBindingOwner", UIParent)

-- Slot order on each layer: face buttons then D-pad.
B.slotKeys = { "PAD3", "PAD4", "PAD2", "PAD1", "PADDUP", "PADDRIGHT", "PADDDOWN", "PADDLEFT" }

-- Each layer maps slot keys to a binding command.
-- Base layer keeps A = Jump and B = Interact (soft-target: talk, loot, gather).
B.layers = {
	{ id = "base", prefix = "", label = "", color = { 1, 1, 1 },
		map = {
			PAD1 = "JUMP", PAD2 = "INTERACTTARGET",
			PAD3 = "ACTIONBUTTON1", PAD4 = "ACTIONBUTTON2",
			PADDUP = "ACTIONBUTTON3", PADDRIGHT = "ACTIONBUTTON4",
			PADDDOWN = "ACTIONBUTTON5", PADDLEFT = "ACTIONBUTTON6",
		} },
	{ id = "l2", prefix = "SHIFT-", label = "L2", color = { 0.45, 0.75, 1 },
		map = {
			PAD3 = "MULTIACTIONBAR1BUTTON1", PAD4 = "MULTIACTIONBAR1BUTTON2",
			PAD2 = "MULTIACTIONBAR1BUTTON3", PAD1 = "MULTIACTIONBAR1BUTTON4",
			PADDUP = "MULTIACTIONBAR1BUTTON5", PADDRIGHT = "MULTIACTIONBAR1BUTTON6",
			PADDDOWN = "MULTIACTIONBAR1BUTTON7", PADDLEFT = "MULTIACTIONBAR1BUTTON8",
		} },
	{ id = "r2", prefix = "CTRL-", label = "R2", color = { 1, 0.55, 0.35 },
		map = {
			PAD3 = "MULTIACTIONBAR2BUTTON1", PAD4 = "MULTIACTIONBAR2BUTTON2",
			PAD2 = "MULTIACTIONBAR2BUTTON3", PAD1 = "MULTIACTIONBAR2BUTTON4",
			PADDUP = "MULTIACTIONBAR2BUTTON5", PADDRIGHT = "MULTIACTIONBAR2BUTTON6",
			PADDDOWN = "MULTIACTIONBAR2BUTTON7", PADDLEFT = "MULTIACTIONBAR2BUTTON8",
		} },
	{ id = "both", prefix = "CTRL-SHIFT-", label = "L2+R2", color = { 0.85, 0.55, 1 },
		map = {
			PAD3 = "MULTIACTIONBAR3BUTTON1", PAD4 = "MULTIACTIONBAR3BUTTON2",
			PAD2 = "MULTIACTIONBAR3BUTTON3", PAD1 = "MULTIACTIONBAR3BUTTON4",
			PADDUP = "MULTIACTIONBAR3BUTTON5", PADDRIGHT = "MULTIACTIONBAR3BUTTON6",
			PADDDOWN = "MULTIACTIONBAR3BUTTON7", PADDLEFT = "MULTIACTIONBAR3BUTTON8",
		} },
}

-- Non-layer buttons: targeting, movement and system.
B.system = {
	PADLSHOULDER = "TARGETPREVIOUSENEMY",
	PADRSHOULDER = "TARGETNEARESTENEMY",
	PADLSTICK = "TOGGLEAUTORUN",
	["SHIFT-PADLSHOULDER"] = "TARGETSELF",
	["SHIFT-PADRSHOULDER"] = "TARGETNEARESTFRIEND",
	["CTRL-PADLSHOULDER"] = "FOCUSTARGET",
	["CTRL-PADRSHOULDER"] = "ASSISTTARGET",
	PADBACK = "TOGGLEWORLDMAP",
	["SHIFT-PADBACK"] = "TOGGLEQUESTLOG",
	["CTRL-PADBACK"] = "OPENALLBAGS",
	["SHIFT-PADFORWARD"] = "TOGGLEGAMEMENU",
}
-- Click-bindings to Hearthpad buttons (created below)
B.clicks = {
	PADFORWARD = "HearthpadHubButton",
	PADRSTICK = "HearthpadCameraButton",
}

B.labels = {
	JUMP = "Jump", INTERACTTARGET = "Interact",
	TARGETPREVIOUSENEMY = "Prev. enemy", TARGETNEARESTENEMY = "Next enemy",
	TOGGLEAUTORUN = "Autorun", TARGETSELF = "Target self", TARGETNEARESTFRIEND = "Next friend",
	FOCUSTARGET = "Set focus", ASSISTTARGET = "Assist",
	TOGGLEWORLDMAP = "World map", TOGGLEQUESTLOG = "Quest log", OPENALLBAGS = "Bags",
	TOGGLEGAMEMENU = "Game menu", HearthpadHubButton = "Hearthpad Hub", HearthpadCameraButton = "Camera mode",
}

-- Which Blizzard button a binding command drives, and its fallback action slot.
local BAR_BUTTONS = {
	ACTIONBUTTON = { "ActionButton", 0 },
	MULTIACTIONBAR1BUTTON = { "MultiBarBottomLeftButton", 60 },
	MULTIACTIONBAR2BUTTON = { "MultiBarBottomRightButton", 48 },
	MULTIACTIONBAR3BUTTON = { "MultiBarRightButton", 24 },
}

function B:ButtonForCommand(cmd)
	if not cmd then return nil end
	local bar, n = cmd:match("^(%u+%d?BUTTON)(%d+)$")
	if not bar then bar, n = cmd:match("^(ACTIONBUTTON)(%d+)$") end
	local def = bar and BAR_BUTTONS[bar]
	if not def then return nil end
	n = tonumber(n)
	return _G[def[1] .. n], def[2] + n
end

-- The live action slot (respects stance/stealth/vehicle paging on the main bar).
function B:SlotForCommand(cmd)
	local btn, fallback = self:ButtonForCommand(cmd)
	if not btn and not fallback then return nil end
	local slot
	if btn then
		slot = btn.action
		if not slot and btn.CalculateAction then
			local ok, s = pcall(btn.CalculateAction, btn)
			if ok then slot = s end
		end
		if not slot and btn.GetAttribute then slot = btn:GetAttribute("action") end
	end
	return HP.Readable(slot) or fallback
end

function B:CommandFor(layerIndex, key)
	local layer = self.layers[layerIndex]
	local cmd = layer and layer.map[key]
	if self.swap and layerIndex == 1 then
		if key == "PAD1" then cmd = layer.map.PAD2 elseif key == "PAD2" then cmd = layer.map.PAD1 end
	end
	return cmd
end

-- Current layer from modifier state (works with GamePadEmulateShift/Ctrl).
function B:ActiveLayer()
	local s, c = IsShiftKeyDown(), IsControlKeyDown()
	if s and c then return 4 elseif c then return 3 elseif s then return 2 end
	return 1
end

function B:Clear()
	if InCombatLockdown() then return HP:AfterCombat("bindings-clear", function() B:Clear() end) end
	ClearOverrideBindings(owner)
end

function B:Apply()
	if InCombatLockdown() then
		HP:AfterCombat("bindings-apply", function() B:Apply() end)
		return
	end
	ClearOverrideBindings(owner)
	if not HP.db.controls.enabled then return end
	self.swap = HP.db.controls.swapJumpInteract

	HP:SetCVarTracked("GamePadEmulateShift", "PADLTRIGGER")
	HP:SetCVarTracked("GamePadEmulateCtrl", "PADRTRIGGER")

	for li, layer in ipairs(self.layers) do
		for _, key in ipairs(self.slotKeys) do
			local cmd = self:CommandFor(li, key)
			if cmd then SetOverrideBinding(owner, false, layer.prefix .. key, cmd) end
		end
	end
	for key, cmd in pairs(self.system) do SetOverrideBinding(owner, false, key, cmd) end
	for key, btn in pairs(self.clicks) do SetOverrideBindingClick(owner, false, key, btn) end
	HP:Fire("HP_BINDINGS_APPLIED")
end

function B:Init()
	-- Small insecure buttons so system actions can be bound like any key.
	local hub = CreateFrame("Button", "HearthpadHubButton", UIParent)
	hub:SetScript("OnClick", function() HP.Hub:Toggle() end)
	local cam = CreateFrame("Button", "HearthpadCameraButton", UIParent)
	cam:SetScript("OnClick", function() HP.Explore:CycleCamera() end)

	HP:RegisterOption({ path = "controls.enabled", label = "Hearthpad crossbar controls", section = "Controls", type = "toggle",
		desc = "Off hands every button back to your own bindings." })
	HP:RegisterOption({ path = "controls.swapJumpInteract", label = "Swap Jump (A) and Interact (B)", section = "Controls", type = "toggle" })

	HP:On("HP_SETTING_CHANGED", function(path)
		if path:find("^controls%.") then B:Apply() end
	end)
	B:Apply()
end
