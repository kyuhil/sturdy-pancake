-- Hearthpad: cinematic dialogue. Replaces the gossip and quest windows with an RPG-style
-- conversation: letterboxed bottom panel, the NPC's 3D portrait, paged typewriter text,
-- a choice list on the right, reward cards and a camera that frames the speaker.
--
-- Voice: if a voiceover addon (Spoken, SpeakStone, Quest To Speech, ForeverDubbed, ...)
-- is loaded, it keeps doing the talking and we just present. Otherwise the built-in
-- text-to-speech can read pages aloud (Y), optionally automatically.
--
-- Falls back to Blizzard's windows in combat, and switches itself off entirely if
-- DialogueUI, Immersion or Storyline is installed.
local _, HP = ...
local D = HP:NewModule("Dialogue")
local T = HP.Theme
local I

local CONFLICTS = { "DialogueUI", "Immersion", "Storyline" }
local VOICE_PATTERNS = { "^Spoken", "SpeakStone", "QuestToSpeech", "^QTS", "ForeverDubbed", "^Lyre", "OutLoud",
	"ForeverTTS", "Forever_TTS", "^Chronicle", "VoiceOver", "CatQuest", "QuestSpeaker", "VoiceLector" }

local ctx = { name = "dialogue", passthrough = { PADBACK = true, PADFORWARD = true } }
local root, panel, model, nameText, titleText, body, pageText, hints, optionBox, rewardBox, voiceTag
local optionRows, rewardCards = {}, {}
local serial = 0

D.active = false

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
local function utf8len(s) return (strlenutf8 and strlenutf8(s)) or #s end

local function paginate(text, limit)
	limit = limit or 330
	local pages = {}
	text = (text or ""):gsub("\r", ""):gsub("^%s+", ""):gsub("%s+$", "")
	if text == "" then return pages end
	for para in (text .. "\n\n"):gmatch("(.-)\n%s*\n") do
		para = para:gsub("\n", " ")
		if para ~= "" then
			local current = (#pages > 0 and #pages[#pages] < limit * 0.45) and table.remove(pages) or nil
			if current then current = current .. "\n\n" end
			for sentence in para:gmatch("[^%.!%?]+[%.!%?]*[\"']?%s*") do
				if current and #current + #sentence > limit then
					pages[#pages + 1] = current:gsub("%s+$", "")
					current = sentence
				else
					current = (current or "") .. sentence
				end
			end
			if current and current ~= "" then pages[#pages + 1] = current:gsub("%s+$", "") end
		end
	end
	return pages
end

local function addonLoaded(name)
	return C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded(name)
end

function D:DetectVoiceAddon()
	if not (C_AddOns and C_AddOns.GetNumAddOns) then return nil end
	for i = 1, C_AddOns.GetNumAddOns() do
		local name, title = C_AddOns.GetAddOnInfo(i)
		if name and C_AddOns.IsAddOnLoaded(i) then
			for _, pat in ipairs(VOICE_PATTERNS) do
				if name:find(pat) then
					return ((title or name):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
				end
			end
		end
	end
end

---------------------------------------------------------------------------
-- Built-in TTS fallback
---------------------------------------------------------------------------
local function pickVoice()
	if not (C_VoiceChat and C_VoiceChat.GetTtsVoices) then return nil end
	local voices = C_VoiceChat.GetTtsVoices()
	if not voices or #voices == 0 then return nil end
	local female = UnitExists("npc") and UnitSex("npc") == 3
	for _, v in ipairs(voices) do
		local n = (v.name or ""):lower()
		local isFemale = n:find("female") or n:find("zira") or n:find("hazel") or n:find("susan") or n:find("eva")
		if (female and isFemale) or (not female and not isFemale) then return v.voiceID end
	end
	return voices[1].voiceID
end

function D:StopSpeaking()
	if C_VoiceChat and C_VoiceChat.StopSpeakingText then pcall(C_VoiceChat.StopSpeakingText) end
end

function D:Speak(text)
	if self.voiceAddon or not text or not (C_VoiceChat and C_VoiceChat.SpeakText) then return end
	self:StopSpeaking()
	local voice = pickVoice()
	if not voice then return end
	text = text:gsub("<.->", "")
	-- The SpeakText signature has changed across clients; try the destination form first.
	local dest = Enum and Enum.VoiceTtsDestination and Enum.VoiceTtsDestination.LocalPlayback
	if dest then
		if pcall(C_VoiceChat.SpeakText, voice, text, dest, 0, 100) then return end
	end
	pcall(C_VoiceChat.SpeakText, voice, text, 0, 100)
end

---------------------------------------------------------------------------
-- Camera framing
---------------------------------------------------------------------------
local savedCam
local function frameSpeaker()
	if not HP.db.dialogue.camera or InCombatLockdown() or IsMounted() or savedCam then return end
	if not UnitExists("npc") then return end
	savedCam = {
		zoom = GetCameraZoom and GetCameraZoom(),
		over = GetCVar("test_cameraOverShoulder"),
		pitch = GetCVar("test_cameraDynamicPitch"),
	}
	pcall(SetCVar, "test_cameraOverShoulder", "1.6")
	pcall(SetCVar, "test_cameraDynamicPitch", "1")
	HP.Explore.ZoomTo(4)
end

local function restoreCamera()
	if not savedCam then return end
	if savedCam.over then pcall(SetCVar, "test_cameraOverShoulder", savedCam.over) end
	if savedCam.pitch then pcall(SetCVar, "test_cameraDynamicPitch", savedCam.pitch) end
	if savedCam.zoom and not InCombatLockdown() then HP.Explore.ZoomTo(savedCam.zoom) end
	savedCam = nil
end

---------------------------------------------------------------------------
-- UI construction
---------------------------------------------------------------------------
local function build()
	root = CreateFrame("Frame", "HearthpadDialogue", UIParent)
	root:SetAllPoints(UIParent)
	root:SetFrameStrata("HIGH")
	root:Hide()

	local letterbox = CreateFrame("Frame", nil, root)
	letterbox:SetPoint("BOTTOMLEFT") letterbox:SetPoint("BOTTOMRIGHT")
	letterbox:SetHeight(360)
	T.Gradient(letterbox, 0, 0.92)
	local topBar = root:CreateTexture(nil, "BACKGROUND")
	topBar:SetPoint("TOPLEFT") topBar:SetPoint("TOPRIGHT")
	topBar:SetHeight(46)
	topBar:SetColorTexture(0, 0, 0, 0.85)

	panel = CreateFrame("Frame", nil, root)
	panel:SetSize(1000, 230)
	panel:SetPoint("BOTTOM", 0, 34)

	model = CreateFrame("PlayerModel", nil, panel)
	model:SetSize(210, 250)
	model:SetPoint("BOTTOMLEFT", 0, 0)

	nameText = T.Text(panel, 24, T.color.accent, "OUTLINE")
	nameText:SetPoint("TOPLEFT", 230, -6)
	titleText = T.Text(panel, 15, T.color.dim)
	titleText:SetPoint("LEFT", nameText, "RIGHT", 14, -2)

	local rule = panel:CreateTexture(nil, "ARTWORK")
	rule:SetPoint("TOPLEFT", nameText, "BOTTOMLEFT", 0, -6)
	rule:SetSize(500, 1)
	rule:SetColorTexture(1, 0.82, 0.38, 0.35)

	body = T.Text(panel, 19, T.color.text)
	body:SetPoint("TOPLEFT", nameText, "BOTTOMLEFT", 0, -16)
	body:SetWidth(740)
	body:SetJustifyH("LEFT")
	body:SetJustifyV("TOP")
	body:SetSpacing(4)

	pageText = T.Text(panel, 13, T.color.dim)
	pageText:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -8, 34)

	voiceTag = T.Text(panel, 13, T.color.dim)
	voiceTag:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 230, 34)

	hints = T.HintBar(panel, nil, 24)
	hints:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 230, 0)

	optionBox = CreateFrame("Frame", nil, root)
	optionBox:SetSize(380, 10)
	optionBox:SetPoint("BOTTOMRIGHT", panel, "TOPRIGHT", 0, 16)

	rewardBox = CreateFrame("Frame", nil, root)
	rewardBox:SetSize(900, 60)
	rewardBox:SetPoint("BOTTOM", panel, "TOP", -110, 16)
	rewardBox.summary = T.Text(rewardBox, 15, T.color.text, "OUTLINE")
	rewardBox.summary:SetPoint("BOTTOMLEFT", rewardBox, "TOPLEFT", 0, 4)

	-- typewriter
	root:SetScript("OnUpdate", function(_, elapsed)
		if not D.typing then return end
		D.revealed = D.revealed + elapsed * (HP.db.dialogue.typeSpeed or 60)
		if D.revealed >= D.pageLen then
			D:FinishTyping()
		else
			body:SetAlphaGradient(math.floor(D.revealed), 12)
		end
	end)
end

local function optionRow(i)
	local r = optionRows[i]
	if r then return r end
	r = CreateFrame("Frame", nil, optionBox)
	r:SetSize(380, 34)
	r.bg = r:CreateTexture(nil, "BACKGROUND")
	r.bg:SetAllPoints()
	r.bg:SetColorTexture(0, 0, 0, 0.6)
	r.bar = r:CreateTexture(nil, "ARTWORK")
	r.bar:SetPoint("TOPLEFT") r.bar:SetPoint("BOTTOMLEFT")
	r.bar:SetWidth(3)
	r.bar:SetColorTexture(unpack(T.color.accent))
	r.icon = r:CreateTexture(nil, "ARTWORK")
	r.icon:SetSize(20, 20)
	r.icon:SetPoint("LEFT", 12, 0)
	r.mark = T.Text(r, 20, T.color.accent, "OUTLINE")
	r.mark:SetPoint("CENTER", r.icon)
	r.text = T.Text(r, 16, T.color.text)
	r.text:SetPoint("LEFT", r.icon, "RIGHT", 10, 0)
	r.text:SetPoint("RIGHT", -40, 0)
	r.text:SetJustifyH("LEFT")
	r.text:SetWordWrap(false)
	r.glyph = T.Glyph(r, "PAD1", 22)
	r.glyph:SetPoint("RIGHT", -8, 0)
	optionRows[i] = r
	return r
end

local function rewardCard(i)
	local c = rewardCards[i]
	if c then return c end
	c = CreateFrame("Frame", nil, rewardBox, "BackdropTemplate")
	c:SetSize(210, 50)
	c:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
	c.icon = c:CreateTexture(nil, "ARTWORK")
	c.icon:SetSize(40, 40)
	c.icon:SetPoint("LEFT", 5, 0)
	c.count = T.Text(c, 12, T.color.text, "OUTLINE")
	c.count:SetPoint("BOTTOMRIGHT", c.icon, -1, 1)
	c.name = T.Text(c, 14, T.color.text)
	c.name:SetPoint("LEFT", c.icon, "RIGHT", 8, 0)
	c.name:SetPoint("RIGHT", -6, 0)
	c.name:SetJustifyH("LEFT")
	c.name:SetWordWrap(true)
	c.name:SetMaxLines(2)
	rewardCards[i] = c
	return c
end

---------------------------------------------------------------------------
-- Rendering
---------------------------------------------------------------------------
function D:RenderOptions()
	local showing = not self.typing and self.page == #self.pages
	for i, r in ipairs(optionRows) do r:Hide() end
	if not showing then optionBox:Hide() return end
	optionBox:Show()
	local n = #self.options
	for i, opt in ipairs(self.options) do
		local r = optionRow(i)
		r:ClearAllPoints()
		r:SetPoint("BOTTOMRIGHT", optionBox, "BOTTOMRIGHT", 0, (n - i) * 38)
		r.text:SetText(opt.text)
		local c = opt.color or T.color.text
		r.text:SetTextColor(c[1], c[2], c[3])
		if opt.icon then r.icon:SetTexture(opt.icon) r.icon:Show() r.mark:SetText("")
		else r.icon:SetTexture(nil) r.mark:SetText(opt.mark or "•") end
		local sel = (i == self.sel)
		r.bar:SetShown(sel)
		r.glyph:SetShown(sel)
		r.bg:SetColorTexture(sel and 0.16 or 0, sel and 0.13 or 0, sel and 0.06 or 0, sel and 0.85 or 0.6)
		r:Show()
	end
	optionBox:SetHeight(math.max(1, n * 38))
end

function D:RenderRewards()
	for _, c in ipairs(rewardCards) do c:Hide() end
	local list = self.rewards or {}
	rewardBox:SetShown(#list > 0 or (self.rewardSummary or "") ~= "")
	rewardBox.summary:SetText(self.rewardSummary or "")
	for i, r in ipairs(list) do
		local c = rewardCard(i)
		c:ClearAllPoints()
		c:SetPoint("BOTTOMLEFT", rewardBox, "BOTTOMLEFT", (i - 1) * 218, 0)
		c.icon:SetTexture(r.texture)
		c.count:SetText(r.count and r.count > 1 and r.count or "")
		c.name:SetText(r.name or "")
		local q = r.quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[r.quality]
		if q then c.name:SetTextColor(q.r, q.g, q.b) else c.name:SetTextColor(unpack(T.color.text)) end
		local sel = r.choosable and i == self.rewardSel
		c:SetBackdropColor(0, 0, 0, 0.7)
		if sel then c:SetBackdropBorderColor(unpack(T.color.accent))
		elseif r.choosable then c:SetBackdropBorderColor(1, 1, 1, 0.25)
		else c:SetBackdropBorderColor(1, 1, 1, 0.08) end
		c:Show()
		if sel then
			GameTooltip:SetOwner(c, "ANCHOR_TOP")
			pcall(GameTooltip.SetQuestItem, GameTooltip, r.type, r.index)
			GameTooltip:Show()
		end
	end
end

function D:RenderHints()
	local list = {}
	local lastPage = self.page >= #self.pages
	if self.typing or not lastPage then list[#list + 1] = { "PAD1", "Continue" }
	elseif #self.options > 0 then list[#list + 1] = { "PAD1", "Choose" } end
	if self.hasChoices then list[#list + 1] = { "PADDLEFT", "Reward" } end
	if #self.options > 1 and lastPage then list[#list + 1] = { "PADDUP", "Option" } end
	list[#list + 1] = { "PAD3", "Skip" }
	if not self.voiceAddon and C_VoiceChat and C_VoiceChat.SpeakText then list[#list + 1] = { "PAD4", "Read aloud" } end
	list[#list + 1] = { "PAD2", self.mode == "detail" and "Decline" or "Goodbye" }
	hints:SetHints(list)
end

function D:ShowPage(i)
	self.page = HP.Clamp(i, 1, math.max(1, #self.pages))
	local text = self.pages[self.page] or ""
	body:SetText(text)
	self.pageLen = utf8len(text)
	pageText:SetText(#self.pages > 1 and (self.page .. " / " .. #self.pages) or "")
	if HP.db.dialogue.typewriter and self.pageLen > 0 then
		self.typing, self.revealed = true, 0
		body:SetAlphaGradient(0, 12)
		if model:IsShown() then pcall(model.SetAnimation, model, 60) end -- talk
	else
		self:FinishTyping()
	end
	if HP.db.dialogue.tts and HP.db.dialogue.autoSpeak then self:Speak(text) end
	self:RenderOptions()
	self:RenderHints()
end

function D:FinishTyping()
	self.typing = false
	-- push the fade point past the last character = everything visible
	body:SetAlphaGradient(utf8len(body:GetText() or "") + 1, 1)
	if model:IsShown() then pcall(model.SetAnimation, model, 0) end
	self:RenderOptions()
	self:RenderHints()
end

---------------------------------------------------------------------------
-- Data collection per interaction type
---------------------------------------------------------------------------
local GOLD, GREY = { 1, 0.82, 0.38 }, { 0.6, 0.6, 0.6 }

local function collectRewards(includeChoices, required)
	local list, summary = {}, {}
	if required then
		for i = 1, (GetNumQuestItems and GetNumQuestItems() or 0) do
			local name, tex, count, quality = GetQuestItemInfo("required", i)
			list[#list + 1] = { type = "required", index = i, name = name, texture = tex, count = count, quality = quality }
		end
		if #list > 0 then summary[#summary + 1] = "Bring:" end
		return list, table.concat(summary, " ")
	end
	local money = GetRewardMoney and GetRewardMoney() or 0
	if money > 0 then summary[#summary + 1] = GetCoinTextureString(money) end
	local xp = GetRewardXP and GetRewardXP() or 0
	if xp > 0 then summary[#summary + 1] = BreakUpLargeNumbers(xp) .. " XP" end
	local nChoices = GetNumQuestChoices and GetNumQuestChoices() or 0
	for i = 1, nChoices do
		local name, tex, count, quality = GetQuestItemInfo("choice", i)
		list[#list + 1] = { type = "choice", index = i, name = name, texture = tex, count = count, quality = quality,
			choosable = includeChoices and nChoices > 1 }
	end
	for i = 1, (GetNumQuestRewards and GetNumQuestRewards() or 0) do
		local name, tex, count, quality = GetQuestItemInfo("reward", i)
		list[#list + 1] = { type = "reward", index = i, name = name, texture = tex, count = count, quality = quality }
	end
	if nChoices > 1 then summary[#summary + 1] = includeChoices and "Choose one:" or "Choice of:" end
	return list, table.concat(summary, "   ")
end

local builders = {}

function builders.gossip()
	local opts = {}
	for _, q in ipairs(C_GossipInfo.GetActiveQuests() or {}) do
		opts[#opts + 1] = { text = q.title, mark = "?", color = q.isComplete and GOLD or GREY,
			run = function() C_GossipInfo.SelectActiveQuest(q.questID) end }
	end
	for _, q in ipairs(C_GossipInfo.GetAvailableQuests() or {}) do
		opts[#opts + 1] = { text = q.title, mark = "!", color = q.isTrivial and GREY or GOLD,
			run = function() C_GossipInfo.SelectAvailableQuest(q.questID) end }
	end
	local gossip = C_GossipInfo.GetOptions() or {}
	table.sort(gossip, function(a, b) return (a.orderIndex or 0) < (b.orderIndex or 0) end)
	for _, o in ipairs(gossip) do
		opts[#opts + 1] = { text = o.name, icon = o.icon,
			run = function() C_GossipInfo.SelectOption(o.gossipOptionID) end }
	end
	opts[#opts + 1] = { text = "Goodbye", mark = "×", color = GREY, run = function() C_GossipInfo.CloseGossip() end }
	return C_GossipInfo.GetText(), opts, nil
end

function builders.greeting()
	local opts = {}
	for i = 1, GetNumActiveQuests() do
		local title, complete = GetActiveTitle(i)
		opts[#opts + 1] = { text = title, mark = "?", color = complete and GOLD or GREY, run = function() SelectActiveQuest(i) end }
	end
	for i = 1, GetNumAvailableQuests() do
		opts[#opts + 1] = { text = GetAvailableTitle(i), mark = "!", color = GOLD, run = function() SelectAvailableQuest(i) end }
	end
	opts[#opts + 1] = { text = "Goodbye", mark = "×", color = GREY, run = function() CloseQuest() end }
	return GetGreetingText(), opts, nil
end

function builders.detail()
	local text = GetQuestText() or ""
	local obj = GetObjectiveText and GetObjectiveText() or ""
	local auto = QuestGetAutoAccept and QuestGetAutoAccept()
	local opts = {
		{ text = auto and "Continue" or "Accept quest", mark = "!", color = GOLD,
			run = function() if auto then CloseQuest() else AcceptQuest() end end },
		{ text = "Decline", mark = "×", color = GREY, run = function() DeclineQuest() end },
	}
	return text, opts, obj ~= "" and ("|cffffd060Objectives|r\n" .. obj) or nil
end

function builders.progress()
	local opts = {}
	if IsQuestCompletable() then
		opts[#opts + 1] = { text = "Hand in", mark = "?", color = GOLD, run = function() CompleteQuest() end }
	end
	opts[#opts + 1] = { text = "Goodbye", mark = "×", color = GREY, run = function() CloseQuest() end }
	return GetProgressText(), opts, nil
end

function builders.complete()
	local opts = {
		{ text = "Complete quest", mark = "?", color = GOLD, run = function()
			local n = GetNumQuestChoices()
			GetQuestReward(n > 0 and (D.rewardSel or 1) or 0)
		end },
	}
	return GetRewardText(), opts, nil
end

---------------------------------------------------------------------------
-- Open / close
---------------------------------------------------------------------------
local function hideBlizzard(hide)
	for _, f in ipairs({ GossipFrame, QuestFrame }) do
		if f then f:SetAlpha(hide and 0 or 1) end
	end
end

function D:Owns(frame)
	return self.active and (frame == GossipFrame or frame == QuestFrame)
end

function D:VoiceMode()
	return self.voiceAddon and (HP.db.dialogue.voiceMode or "compact") or "full"
end

function D:Open(mode)
	if not HP.db.dialogue.enabled or self.disabledReason then return end
	local voiceMode = self:VoiceMode()
	if voiceMode == "handoff" then return end
	serial = serial + 1
	if not self.active then
		if not I:Push(ctx) then return end -- combat: Blizzard's window stays visible
	end
	self.mode = mode
	local text, opts, extra = builders[mode]()
	self.options = opts
	self.sel = 1
	if voiceMode == "compact" then
		-- The voice addon is already showing these words; keep only what it doesn't show
		-- (objectives), so the choices appear straight away and nothing is duplicated.
		self.pages = extra and paginate(extra) or {}
	else
		self.pages = paginate(text)
		if extra then for _, p in ipairs(paginate(extra)) do self.pages[#self.pages + 1] = p end end
	end
	if #self.pages == 0 then self.pages = { "" } end
	panel:SetHeight(voiceMode == "compact" and 150 or 230)

	self.rewards, self.rewardSummary, self.hasChoices = nil, nil, false
	if mode == "detail" then
		self.rewards, self.rewardSummary = collectRewards(false)
	elseif mode == "complete" then
		self.rewards, self.rewardSummary = collectRewards(true)
		self.hasChoices = GetNumQuestChoices() > 1
		self.rewardSel = 1
	elseif mode == "progress" then
		self.rewards, self.rewardSummary = collectRewards(false, true)
	end

	local npcName = UnitExists("npc") and UnitName("npc") or (QuestFrameNpcNameText and QuestFrameNpcNameText:GetText()) or ""
	nameText:SetText(npcName)
	local title = (mode == "detail" or mode == "progress" or mode == "complete") and GetTitleText() or ""
	titleText:SetText(title or "")
	if UnitExists("npc") then
		model:Show()
		model:ClearModel()
		model:SetUnit("npc")
		pcall(model.SetPortraitZoom, model, 0.7)
	else
		model:Hide()
	end
	voiceTag:SetText(self.voiceAddon and ("Voiced by " .. self.voiceAddon) or "")

	if not self.active then
		self.active = true
		hideBlizzard(true)
		root:Show()
		HP.Crossbar:SetShown(false)
		frameSpeaker()
		HP.Gamepad:Rumble("tick")
	end
	GameTooltip:Hide()
	self:RenderRewards()
	self:ShowPage(1)
end

function D:Close()
	if not self.active then return end
	self.active = false
	self.typing = false
	self:StopSpeaking()
	GameTooltip:Hide()
	root:Hide()
	hideBlizzard(false)
	restoreCamera()
	I:Pop(ctx)
	HP.Crossbar:SetShown(HP.db.hud.crossbar and HP.db.controls.enabled)
end

-- Quest/gossip windows close and reopen between steps (gossip -> detail); wait a beat.
local function deferredClose()
	local s = serial
	C_Timer.After(0.12, function() if s == serial then D:Close() end end)
end

function D:Choose(opt)
	if not opt then return end
	HP.Gamepad:Rumble("light")
	PlaySound(SOUNDKIT and SOUNDKIT.IG_QUEST_LIST_SELECT or 875)
	pcall(opt.run)
end

function ctx:OnKey(key)
	if key == "PAD1" then
		if D.typing then D:FinishTyping()
		elseif D.page < #D.pages then D:ShowPage(D.page + 1)
		else D:Choose(D.options[D.sel]) end
	elseif key == "PAD2" then
		HP.Gamepad:Rumble("tick")
		if D.mode == "detail" then DeclineQuest()
		elseif D.mode == "gossip" then C_GossipInfo.CloseGossip()
		else CloseQuest() end
	elseif key == "PAD3" then
		D:ShowPage(#D.pages)
		D:FinishTyping()
	elseif key == "PAD4" then
		D:Speak(D.pages[D.page])
	elseif key == "PADDUP" or key == "PADDDOWN" then
		if D.typing or D.page < #D.pages then return end
		local n = #D.options
		if n == 0 then return end
		D.sel = (D.sel - 1 + (key == "PADDDOWN" and 1 or -1)) % n + 1
		HP.Gamepad:Rumble("tick")
		D:RenderOptions()
	elseif key == "PADDLEFT" or key == "PADDRIGHT" then
		local step = key == "PADDRIGHT" and 1 or -1
		if D.hasChoices then
			local n = GetNumQuestChoices()
			D.rewardSel = (D.rewardSel - 1 + step) % n + 1
			HP.Gamepad:Rumble("tick")
			D:RenderRewards()
		elseif not D.typing then
			D:ShowPage(D.page + step)
		end
	elseif key == "PADLSHOULDER" then D:ShowPage(D.page - 1)
	elseif key == "PADRSHOULDER" then D:ShowPage(D.page + 1)
	end
end

function ctx:OnCombat()
	-- Hand the conversation back to Blizzard's window so nothing is lost mid-fight.
	hideBlizzard(false)
	root:Hide()
	D.active = false
	D.typing = false
	restoreCamera()
	HP:AfterCombat("dialogue-pop", function() I:Pop(ctx) end)
end

---------------------------------------------------------------------------
function D:Init()
	I = HP.Input
	HP:RegisterOption({ path = "dialogue.enabled", label = "Cinematic dialogue", section = "Dialogue", type = "toggle" })
	HP:RegisterOption({ path = "dialogue.typewriter", label = "Typewriter text", section = "Dialogue", type = "toggle" })
	HP:RegisterOption({ path = "dialogue.typeSpeed", label = "Text speed", section = "Dialogue", type = "range", min = 20, max = 160, step = 10 })
	HP:RegisterOption({ path = "dialogue.camera", label = "Frame the speaker with the camera", section = "Dialogue", type = "toggle" })
	HP:RegisterOption({ path = "dialogue.voiceMode", label = "With a voice addon (Spoken etc.)", section = "Dialogue", type = "choice",
		values = { { "compact", "It shows the words" }, { "full", "Hearthpad shows text" }, { "handoff", "Hand off fully" } },
		desc = "Spoken and similar addons show their own subtitles. 'It shows the words' keeps Hearthpad to portrait, choices and rewards." })
	HP:RegisterOption({ path = "dialogue.tts", label = "Built-in voice (if no voice addon)", section = "Dialogue", type = "toggle" })
	HP:RegisterOption({ path = "dialogue.autoSpeak", label = "Read every page automatically", section = "Dialogue", type = "toggle" })

	for _, name in ipairs(CONFLICTS) do
		if addonLoaded(name) then
			self.disabledReason = name
			HP:Debug("Dialogue off: " .. name .. " is handling conversations.")
		end
	end
	self.voiceAddon = self:DetectVoiceAddon()
	build()

	HP:On("GOSSIP_SHOW", function() D:Open("gossip") end)
	HP:On("QUEST_GREETING", function() D:Open("greeting") end)
	HP:On("QUEST_DETAIL", function() D:Open("detail") end)
	HP:On("QUEST_PROGRESS", function() D:Open("progress") end)
	HP:On("QUEST_COMPLETE", function() D:Open("complete") end)
	HP:On("QUEST_ITEM_UPDATE", function() if D.active then D:RenderRewards() end end)
	HP:On("GOSSIP_CLOSED", deferredClose)
	HP:On("QUEST_FINISHED", deferredClose)
	HP:On("HP_SETTING_CHANGED", function(path, value)
		if path == "dialogue.enabled" and not value then D:Close() end
	end)
end
