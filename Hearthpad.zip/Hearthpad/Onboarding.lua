-- Hearthpad: first-run welcome, the one-press Steam Deck preset, and a live controls
-- reference that shows what every button does on the layer you are holding.
local _, HP = ...
local O = HP:NewModule("Onboarding")
local T = HP.Theme
local I

-- Gentle, reversible defaults for handheld play (restored by /hp restore).
O.deckCVars = {
	GamePadEnable = 1,
	SoftTargetEnemy = 3,          -- always soft-target enemies in front of you
	SoftTargetInteract = 3,       -- talk / loot / gather without precise aiming
	SoftTargetIconInteract = 1,
	SoftTargetIconGameObject = 1,
	SoftTargetTooltipInteract = 1,
	GamePadCameraYawSpeed = 1.4,
	GamePadCameraPitchSpeed = 0.9,
	GamePadFaceMovementMaxAngle = 115,
	GamePadCursorAutoEnable = 1,
}

function O:ApplyDeckPreset()
	for k, v in pairs(self.deckCVars) do HP:SetCVarTracked(k, v) end
	HP:Set("controls.enabled", true)
	HP.Explore:ApplyCamera(HP.db.explore.cameraMode, true)
end

---------------------------------------------------------------------------
-- Welcome card
---------------------------------------------------------------------------
local welcome
local welcomeCtx = { name = "welcome" }

local function buildWelcome()
	welcome = T.Panel(UIParent, "HearthpadWelcome", "DIALOG")
	welcome:SetSize(640, 300)
	welcome:SetPoint("CENTER", 0, 40)
	local title = T.Text(welcome, 30, T.color.accent, "OUTLINE")
	title:SetPoint("TOP", 0, -26)
	title:SetText("Welcome to Hearthpad")
	welcome.body = T.Text(welcome, 16, T.color.text)
	welcome.body:SetPoint("TOP", title, "BOTTOM", 0, -18)
	welcome.body:SetWidth(560)
	welcome.body:SetSpacing(4)
	welcome.hints = T.HintBar(welcome, { { "PAD1", "Set up for handheld" }, { "PAD2", "Not now" } }, 28)
	welcome.hints:SetPoint("BOTTOM", 0, 22)
	welcome:Hide()
end

function O:ShowWelcome()
	if InCombatLockdown() then return HP:AfterCombat("welcome", function() O:ShowWelcome() end) end
	local where = HP.isSteamDeck and "It looks like you're on a |cffffd060Steam Deck|r. " or ""
	welcome.body:SetText(where .. "Hearthpad turns the triggers into four layers of abilities, lets the D-pad drive every window, "
		.. "and makes conversations, exploration and combat feel built for a controller.\n\n"
		.. "Setting up enables gamepad mode, soft targeting and comfortable camera speeds. Everything is reversible with /hp restore.")
	welcome.hints:ClearAllPoints()
	welcome.hints:SetPoint("BOTTOM", 0, 22)
	if I:Push(welcomeCtx) then welcome:Show() end
end

function welcomeCtx:OnKey(key)
	if key == "PAD1" then
		O:ApplyDeckPreset()
		HP.db.firstRunDone = true
		welcome:Hide()
		I:Pop(welcomeCtx)
		HP.Gamepad:Rumble("levelup")
		C_Timer.After(0.2, function() O:ShowControls() end)
	elseif key == "PAD2" then
		HP.db.firstRunDone = true
		welcome:Hide()
		I:Pop(welcomeCtx)
	end
end
function welcomeCtx:OnCombat() welcome:Hide() end

---------------------------------------------------------------------------
-- Controls reference
---------------------------------------------------------------------------
local overlay
local controlsCtx = { name = "controls", passthrough = { PADBACK = true } }

local function actionName(cmd)
	local B = HP.Bindings
	if B.labels[cmd] then return B.labels[cmd] end
	local slot = B:SlotForCommand(cmd)
	if not slot then return cmd end
	local kind, id = GetActionInfo(slot)
	kind, id = HP.Readable(kind), HP.Readable(id)
	if kind == "spell" and id then
		local name = (C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(id)) or (GetSpellInfo and GetSpellInfo(id))
		if name then return name end
	elseif kind == "item" and id then
		local name = (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(id)) or (GetItemInfo and GetItemInfo(id))
		if name then return name end
	elseif kind == "macro" then
		return GetActionText(slot) or "Macro"
	end
	if not kind then return "|cff666666empty — slot " .. slot .. "|r" end
	return kind
end

local function entry(parent)
	local e = CreateFrame("Frame", nil, parent)
	e:SetSize(330, 30)
	e.glyph = T.Glyph(e, "PAD1", 26)
	e.glyph:SetPoint("LEFT")
	e.text = T.Text(e, 16, T.color.text)
	e.text:SetPoint("LEFT", 36, 0)
	e.text:SetWidth(290)
	e.text:SetJustifyH("LEFT")
	e.text:SetWordWrap(false)
	return e
end

local LEFT_KEYS = { "PADDUP", "PADDRIGHT", "PADDDOWN", "PADDLEFT", "PADLSHOULDER", "PADLSTICK", "PADBACK" }
local RIGHT_KEYS = { "PAD4", "PAD2", "PAD1", "PAD3", "PADRSHOULDER", "PADRSTICK", "PADFORWARD" }

local function buildOverlay()
	overlay = T.Panel(UIParent, "HearthpadControls", "DIALOG")
	overlay:SetSize(780, 430)
	overlay:SetPoint("CENTER")
	overlay.title = T.Text(overlay, 26, T.color.accent, "OUTLINE")
	overlay.title:SetPoint("TOP", 0, -18)
	overlay.layer = T.Text(overlay, 15, T.color.dim)
	overlay.layer:SetPoint("TOP", overlay.title, "BOTTOM", 0, -6)
	overlay.left, overlay.right = {}, {}
	for i in ipairs(LEFT_KEYS) do
		local e = entry(overlay)
		e:SetPoint("TOPLEFT", 36, -86 - (i - 1) * 38)
		overlay.left[i] = e
	end
	for i in ipairs(RIGHT_KEYS) do
		local e = entry(overlay)
		e:SetPoint("TOPLEFT", 410, -86 - (i - 1) * 38)
		overlay.right[i] = e
	end
	overlay.hints = T.HintBar(overlay, { { "PADLTRIGGER", "/" }, { "PADRTRIGGER", "Hold to preview layers" }, { "PAD2", "Close" } }, 26)
	overlay.hints:SetPoint("BOTTOM", 0, 18)
	overlay:Hide()
end

local function systemCommand(key, layer)
	local B = HP.Bindings
	local prefix = B.layers[layer].prefix
	return B.system[prefix .. key] or B.clicks[prefix .. key] or (layer == 1 and (B.system[key] or B.clicks[key]))
end

local function fill(list, keys, layer)
	for i, key in ipairs(keys) do
		local e = list[i]
		e.glyph:Hide()
		e.glyph = T.Glyph(e, key, 26)
		e.glyph:SetPoint("LEFT")
		local cmd = HP.Bindings:CommandFor(layer, key) or systemCommand(key, layer)
		e.text:SetText(cmd and actionName(cmd) or "|cff666666—|r")
	end
end

function O:RenderControls()
	if not overlay:IsShown() then return end
	local li = HP.Bindings:ActiveLayer()
	if li == self.renderedLayer then return end
	self.renderedLayer = li
	local layer = HP.Bindings.layers[li]
	overlay.title:SetText("Controls")
	overlay.layer:SetText(li == 1 and "Base layer" or ("Holding " .. layer.label))
	fill(overlay.left, LEFT_KEYS, li)
	fill(overlay.right, RIGHT_KEYS, li)
end

function O:ShowControls()
	if InCombatLockdown() then return end
	if not I:Push(controlsCtx) then return end
	self.renderedLayer = nil
	overlay:Show()
	self:RenderControls()
end

function controlsCtx:OnKey(key)
	if key == "PAD2" or key == "PADFORWARD" then
		overlay:Hide()
		I:Pop(controlsCtx)
	end
end
function controlsCtx:OnCombat() overlay:Hide() HP:AfterCombat("controls-pop", function() I:Pop(controlsCtx) end) end

function O:Init()
	I = HP.Input
	buildWelcome()
	buildOverlay()
	C_Timer.NewTicker(0.05, function() if overlay:IsShown() then O:RenderControls() end end)
	HP:On("PLAYER_ENTERING_WORLD", function(isLogin)
		if isLogin and not HP.db.firstRunDone then C_Timer.After(3, function() O:ShowWelcome() end) end
	end)
end
