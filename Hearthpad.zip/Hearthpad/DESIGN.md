# Hearthpad — design notes

## Principles
1. **Build on Blizzard's systems, don't replace them.** Actions run through Blizzard's own action buttons via bindings. That keeps them secure, keeps them working in combat, and keeps stance paging and procs intact. Hearthpad changes how things look and how you reach them, not how they run.
2. **Combat always wins.** Every Hearthpad menu context releases the D-pad and face buttons inside `PLAYER_REGEN_DISABLED`, the last moment before lockdown, so combat never begins with a menu holding your buttons.
3. **Degrade, never break.** Anything that reads combat state goes through `HP.Readable`. If Forever hides a value as secret, that one effect turns off quietly.
4. **Reversible.** CVars are changed through `HP:SetCVarTracked`, which remembers the old values. Bindings are override bindings that are never saved. `/hp restore` undoes everything.
5. **One visual language.** Every surface uses `Theme.lua`: the hearth-gold accent, Xbox-coloured glyphs, text sized for a 7" screen, and a hint bar showing the available buttons.

## Modules (load order)
| File | Role |
|---|---|
| Core | event bus, modules, saved settings + dotted-path access, options registry, combat queue, slash commands |
| Theme | palette, text, panels, controller glyphs, hint bars, a fader that is safe in combat, toasts |
| Gamepad | polls the controller's mapped state for visual feedback (presses, sticks) and plays haptic patterns |
| Input | stack of input contexts using priority override bindings; secure click proxy |
| Bindings | the 4-layer crossbar scheme and system buttons; maps commands to Blizzard buttons and action slots |
| Crossbar | the HUD showing the live layer |
| Combat | vignettes and combat haptics |
| Explore | camera styles and reactions to combat and mounting, compass, zone cards, immersion fade |
| Navigator | spatial D-pad navigation inside Blizzard windows |
| Dialogue | cinematic gossip/quest UI and the voice-addon bridge |
| Hub | Start menu tiles and the Settings page generated from the options registry |
| Onboarding | welcome card, Deck preset, live controls reference |

## Input contexts
`HP.Input:Push(ctx)` binds the 12 navigation keys, in all four modifier combinations, to hidden buttons that call `ctx:OnKey(key)`. A context can also send A and X through `HearthpadClickProxy`, a `SecureActionButton` of `type="click"`. That makes them genuine clicks on whichever Blizzard button has focus. `passthrough` leaves chosen keys, such as View for the map, with the world bindings. Contexts stack: the Hub opens over the Navigator, and closing it returns you to where you were.

## Roadmap ideas
- **Radial wheels**: emotes, mounts, consumables and quest items on a stick-driven ring. This needs secure buttons whose attributes are set out of combat.
- **Party targeting on the D-pad** while L1 is held, built on secure state drivers.
- **Per-character layouts** and a binding editor in the Hub (assign any spell to a slot without dragging).
- **Bag view built for controllers**: a category grid with sorting and a vendor-junk shortcut.
- **Quest journal**: a story-style log of accepted and completed quests, linked to the dialogue text you've already seen.
- **Map navigation**: stick panning and snapping between points of interest on the world map.
