# Hearthpad

A handheld-first interface for **World of Warcraft: Forever** (client 1.60.x, interface 16001), built for the Steam Deck.

Hearthpad works **on top of Forever's native Gamepad UI**. Movement, camera and Blizzard's own action buttons stay exactly as they are. Hearthpad adds a control scheme, presentation and menus around them, so everything you need is one or two button presses away.

## Install

1. Copy the `Hearthpad` folder into `World of Warcraft/_forever_/Interface/AddOns/`. The folder name has varied between Forever builds (`_classic_beta_` was used during the beta). On a Deck running Battle.net through Proton, the game is inside the Proton prefix you installed it to.
2. In game, go to **Options → Gameplay → Gamepad** and turn on the Gamepad UI.
3. Log in. A welcome card appears; press **A** to apply the handheld setup.

Type `/hp restore` at any time to put back every binding and setting Hearthpad changed.

## Controls

The triggers are layer modifiers: **L2 = Shift, R2 = Ctrl, L2+R2 = both**. Each layer puts 8 abilities on the face buttons and the D-pad, which gives 30 abilities in total. The crossbar HUD always shows the layer you're holding.

| Button | Base layer | Holding L2 | Holding R2 | Holding L2+R2 |
|---|---|---|---|---|
| A / B | Jump / Interact (talk, loot, gather) | Bottom-left bar 4 / 3 | Bottom-right bar 4 / 3 | Right bar 4 / 3 |
| X / Y | Action bar 1 / 2 | Bottom-left bar 1 / 2 | Bottom-right bar 1 / 2 | Right bar 1 / 2 |
| D-pad ↑ → ↓ ← | Action bar 3–6 | Bottom-left bar 5–8 | Bottom-right bar 5–8 | Right bar 5–8 |
| L1 / R1 | Previous / next enemy | Target self / next friend | Set focus / assist | — |
| L3 / R3 | Autorun / camera style | | | |
| View | World map | Quest log | Bags | |
| Menu | Hearthpad Hub | Game menu | | |

Abilities are placed by dragging spells onto Blizzard's action bars, as usual. Hearthpad binds the controller to those bars and never edits your saved key bindings. Type `/hp controls` (or open **Hub → Controls**) to see a live map of every button on every layer. Hold a trigger while it's open to preview that layer.

### Inside windows (bags, vendors, character, talents, mail, map…)
- **D-pad**: move the gold focus ring between buttons
- **A**: click; **X**: right-click (use or equip items)
- **B**: close; **Y**: jump to the next open window
- **L1 / R1**: switch tabs
- **Right stick**: scroll lists

### Conversations
- **D-pad ↑↓**: choose an option; **←→**: choose a reward
- **A**: continue or choose; **B**: decline or say goodbye
- **X**: skip to the end of the text; **Y**: read the page aloud (built-in voice)
- **L1 / R1**: previous / next page

## Features

- **Crossbar HUD.** Two diamond clusters show every button's ability on the layer you're holding, with cooldowns, range and out-of-mana tint, item counts and a pulse when you press. The B slot shows the name of the soft-target you'd interact with.
- **Cinematic dialogue.** Gossip and quest windows become an RPG-style conversation: a letterboxed panel, the NPC's 3D portrait with a talking animation, paged typewriter text, a list of choices, reward cards with tooltips, and a camera that frames the speaker.
- **Voice addons.** Spoken, SpeakStone, Quest To Speech, ForeverDubbed, Lyre, Out Loud, Forever TTS, Chronicle and similar addons are detected automatically. These addons show their own subtitles, so by default Hearthpad lets them show the words and keeps to the portrait, choices, rewards and controls. You can change this under **Settings → Dialogue**:
  - *It shows the words* (default)
  - *Hearthpad shows text*
  - *Hand off fully*: Blizzard's window, with D-pad navigation
  
  With no voice addon installed, the built-in text-to-speech can read pages aloud (**Y**), or read every page automatically.
- **D-pad window navigation.** Focus snaps to the real buttons in Blizzard's windows. Clicks go through a secure proxy, so protected actions such as using a bag item work.
- **Hub (Menu button).** A big-tile menu for every window, plus a Settings page covering every Hearthpad option, all controlled with the controller.
- **Exploration.** Three camera styles (Classic, Explore, Cinematic) that you cycle with R3. The camera pulls back automatically in combat and when mounted. A compass strip shows the direction and distance to your waypoint or tracked quest. New areas get cinematic zone titles, and immersion mode fades the HUD while you explore calmly. Hold a trigger to bring the HUD back for a look.
- **Combat feel.** A screen-edge flash when combat starts, a low-health vignette and heartbeat, and haptics for target lock, interrupts, crowd control, death and level-up.

## Steam Deck setup tips

- In Steam, use the **Gamepad** controller template for the Battle.net shortcut. Map the back grips to keys you want close at hand, for example **L4 → L3** (autorun) and **R4 → R3** (camera style).
- Set the right trackpad to *Mouse*. That covers the rare moment you want a free cursor.
- Edit Mode saves a separate layout for gamepad play. Hide Blizzard's own action bars there if you prefer to see only the crossbar. The bars keep working while hidden.

## Limits and what to verify in game

Forever runs the Midnight-era addon rules, including **secret values**. During combat, addons can't read some numbers, such as health and cooldown timings. Every Hearthpad feature that reads them checks first. If a value is hidden, that one effect (for example a cooldown swipe on the crossbar, or the low-health vignette) switches itself off, and the rest keeps working. Blizzard's own bars always show cooldowns.

Hearthpad has been checked for structure, but it has **not yet been run in the game**. Check these points first when you test it:

1. **Input**: the layer bindings and the Hub/menu contexts take over the D-pad and face buttons when they should, and give them back when they close.
2. **Gamepad state**: `C_GamePad.GetDeviceMappedState` and `ButtonIndexToBinding` report button names (they drive the press pulses and stick scrolling).
3. **Haptics**: `C_GamePad.SetVibration` accepts the vibration types `"Low"` and `"High"`.
4. **Text-to-speech**: the `C_VoiceChat.SpeakText` signature on this client.
5. **Dialogue**: the gossip and quest flow, including moving from gossip into quest details and choosing a reward.

`/hp debug` turns on extra messages.

## Slash commands

`/hp` opens the Hub. The other commands are `/hp controls`, `/hp preset`, `/hp camera`, `/hp welcome`, `/hp restore` and `/hp reset`.
