-- Hearthpad: shared visual language — palette, type scale, panels, controller glyphs, toasts.
-- Everything is sized for a 7" 1280x800 screen read at arm's length.
local _, HP = ...
local T = {}
HP.Theme = T

T.color = {
	bg      = { 0.035, 0.04, 0.055, 0.90 },
	bgSoft  = { 0.07, 0.075, 0.095, 0.85 },
	edge    = { 1.00, 0.82, 0.38, 0.35 },
	accent  = { 1.00, 0.82, 0.38, 1 },     -- hearth gold
	text    = { 0.95, 0.93, 0.88, 1 },
	dim     = { 0.62, 0.60, 0.56, 1 },
	danger  = { 0.92, 0.26, 0.22, 1 },
	ok      = { 0.38, 0.84, 0.46, 1 },
}

-- Xbox-style face colours (the Deck's face buttons are labelled A/B/X/Y)
T.glyph = {
	PAD1 = { "A", 0.36, 0.78, 0.30 },
	PAD2 = { "B", 0.90, 0.28, 0.24 },
	PAD3 = { "X", 0.25, 0.55, 0.95 },
	PAD4 = { "Y", 0.98, 0.78, 0.20 },
	PADLSHOULDER = { "L1" }, PADRSHOULDER = { "R1" },
	PADLTRIGGER = { "L2" },  PADRTRIGGER = { "R2" },
	PADLSTICK = { "L3" },    PADRSTICK = { "R3" },
	PADFORWARD = { "MENU" }, PADBACK = { "VIEW" },
	PADDUP = { "dpad", 0 }, PADDRIGHT = { "dpad", -math.pi / 2 },
	PADDDOWN = { "dpad", math.pi }, PADDLEFT = { "dpad", math.pi / 2 },
}

local FONT = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
T.font = FONT

function T.Text(parent, size, color, flags, layer)
	local fs = parent:CreateFontString(nil, layer or "OVERLAY")
	fs:SetFont(FONT, size or 16, flags or "")
	local c = color or T.color.text
	fs:SetTextColor(c[1], c[2], c[3], c[4] or 1)
	fs:SetShadowColor(0, 0, 0, 0.9)
	fs:SetShadowOffset(1, -1)
	return fs
end

function T.Panel(parent, name, strata)
	local f = CreateFrame("Frame", name, parent or UIParent, "BackdropTemplate")
	f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
	f:SetBackdropColor(unpack(T.color.bg))
	f:SetBackdropBorderColor(unpack(T.color.edge))
	if strata then f:SetFrameStrata(strata) end
	return f
end

-- Soft vertical gradient fill, used for dialogue and hub backdrops.
function T.Gradient(parent, topAlpha, bottomAlpha, layer)
	local tex = parent:CreateTexture(nil, layer or "BACKGROUND")
	tex:SetAllPoints()
	tex:SetColorTexture(1, 1, 1, 1)
	if tex.SetGradient and CreateColor then
		tex:SetGradient("VERTICAL", CreateColor(0, 0, 0, bottomAlpha or 0.9), CreateColor(0, 0, 0, topAlpha or 0))
	else
		tex:SetColorTexture(0, 0, 0, bottomAlpha or 0.8)
	end
	return tex
end

---------------------------------------------------------------------------
-- Controller glyph: coloured disc with a letter, or a D-pad arrow.
---------------------------------------------------------------------------
function T.Glyph(parent, key, size)
	size = size or 22
	local g = CreateFrame("Frame", nil, parent)
	g:SetSize(size, size)
	local def = T.glyph[key] or { key }

	local disc = g:CreateTexture(nil, "ARTWORK")
	disc:SetAllPoints()
	local mask = g:CreateMaskTexture()
	mask:SetTexture("Interface\\CHARACTERFRAME\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
	mask:SetAllPoints()
	disc:AddMaskTexture(mask)
	g.disc = disc

	if def[1] == "dpad" then
		disc:SetColorTexture(0.16, 0.17, 0.2, 0.95)
		local arrow = g:CreateTexture(nil, "OVERLAY")
		arrow:SetTexture("Interface\\ChatFrame\\ChatFrameExpandArrow")
		arrow:SetSize(size * 0.62, size * 0.62)
		arrow:SetPoint("CENTER")
		-- the source art points right; rotate it to face the requested direction
		arrow:SetRotation((def[2] or 0) + math.pi / 2)
		g.arrow = arrow
	else
		local r, gg, b = def[2], def[3], def[4]
		if r then disc:SetColorTexture(r * 0.85, gg * 0.85, b * 0.85, 1)
		else disc:SetColorTexture(0.16, 0.17, 0.2, 0.95) end
		local label = T.Text(g, #def[1] > 2 and size * 0.32 or size * 0.55, T.color.text, "OUTLINE")
		label:SetPoint("CENTER", 0, 0)
		label:SetText(def[1])
		g.label = label
	end
	return g
end

-- "[A] Accept" style hint row used at the bottom of every Hearthpad surface.
function T.HintBar(parent, hints, size)
	local bar = CreateFrame("Frame", nil, parent)
	bar:SetHeight(size or 26)
	bar.items = {}
	function bar:SetHints(list)
		for _, it in ipairs(self.items) do it:Hide() end
		local x = 0
		for i, h in ipairs(list) do
			local it = self.items[i]
			if not it then
				it = CreateFrame("Frame", nil, self)
				it:SetHeight(size or 26)
				it.text = T.Text(it, (size or 26) * 0.6, T.color.text)
				self.items[i] = it
			end
			if it.glyph then it.glyph:Hide() end
			it.glyph = T.Glyph(it, h[1], (size or 26) * 0.85)
			it.glyph:SetPoint("LEFT")
			it.text:ClearAllPoints()
			it.text:SetPoint("LEFT", it.glyph, "RIGHT", 6, 0)
			it.text:SetText(h[2])
			local w = (size or 26) * 0.85 + 6 + it.text:GetStringWidth() + 22
			it:SetWidth(w)
			it:ClearAllPoints()
			it:SetPoint("LEFT", self, "LEFT", x, 0)
			it:Show()
			x = x + w
		end
		self:SetWidth(math.max(1, x))
	end
	if hints then bar:SetHints(hints) end
	return bar
end

---------------------------------------------------------------------------
-- Alpha fader that never calls Show/Hide (safe on protected frames in combat).
---------------------------------------------------------------------------
local fading = {}
local fader = CreateFrame("Frame")
fader:SetScript("OnUpdate", function(_, elapsed)
	local any = false
	for frame, target in pairs(fading) do
		local a = frame:GetAlpha()
		local step = elapsed * 4
		if math.abs(a - target) <= step then
			frame:SetAlpha(target)
			fading[frame] = nil
		else
			frame:SetAlpha(a + (target > a and step or -step))
			any = true
		end
	end
	if not any and not next(fading) then fader:Hide() end
end)
fader:Hide()

function T.FadeTo(frame, alpha)
	if not frame or not frame.SetAlpha then return end
	fading[frame] = alpha
	fader:Show()
end

---------------------------------------------------------------------------
-- Toast: a short centred line for state changes ("Camera: Cinematic").
---------------------------------------------------------------------------
local toast
function HP:Toast(text, color)
	if not toast then
		toast = T.Panel(UIParent, "HearthpadToast", "DIALOG")
		toast:SetHeight(40)
		toast:SetPoint("TOP", 0, -120)
		toast.text = T.Text(toast, 18)
		toast.text:SetPoint("CENTER")
		toast:Hide()
	end
	local c = color or T.color.accent
	toast.text:SetTextColor(c[1], c[2], c[3], 1)
	toast.text:SetText(text)
	toast:SetWidth(toast.text:GetStringWidth() + 48)
	toast:SetAlpha(1)
	toast:Show()
	toast.serial = (toast.serial or 0) + 1
	local serial = toast.serial
	C_Timer.After(1.8, function()
		if toast.serial == serial then T.FadeTo(toast, 0) end
	end)
end
