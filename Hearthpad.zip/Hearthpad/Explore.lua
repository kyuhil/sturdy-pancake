-- Hearthpad: exploration — context-aware camera, a minimal compass with your waypoint,
-- cinematic zone titles, and an immersion mode that lets the world fill the screen
-- until you need the HUD.
local _, HP = ...
local E = HP:NewModule("Explore")
local T = HP.Theme

---------------------------------------------------------------------------
-- Camera
---------------------------------------------------------------------------
-- ActionCam CVars. Values are deliberately gentle; a 7" screen magnifies motion.
E.cameraModes = {
	classic = { label = "Classic", cvars = {
		test_cameraOverShoulder = 0, test_cameraDynamicPitch = 0, test_cameraHeadMovementStrength = 0,
		test_cameraTargetFocusEnemyEnable = 0 }, zoom = nil },
	explore = { label = "Explore", cvars = {
		test_cameraOverShoulder = 0.6, test_cameraDynamicPitch = 1, test_cameraDynamicPitchBaseFovPad = 0.35,
		test_cameraHeadMovementStrength = 0, test_cameraTargetFocusEnemyEnable = 0 }, zoom = 11 },
	cinematic = { label = "Cinematic", cvars = {
		test_cameraOverShoulder = 1.1, test_cameraDynamicPitch = 1, test_cameraDynamicPitchBaseFovPad = 0.45,
		test_cameraHeadMovementStrength = 0.6, test_cameraTargetFocusEnemyEnable = 0 }, zoom = 7 },
}
E.cameraOrder = { "classic", "explore", "cinematic" }

local suppressedWarning = false
local function allowActionCam()
	-- Setting test_ CVars pops Blizzard's "experimental feature" dialog every login.
	if suppressedWarning then return end
	suppressedWarning = true
	pcall(UIParent.UnregisterEvent, UIParent, "EXPERIMENTAL_CVAR_CONFIRMATION_NEEDED")
end

local function zoomTo(target)
	if not target or not GetCameraZoom then return end
	local cur = GetCameraZoom()
	if not cur then return end
	local d = target - cur
	if math.abs(d) < 0.5 then return end
	if d > 0 then pcall(CameraZoomOut, d) else pcall(CameraZoomIn, -d) end
end
E.ZoomTo = zoomTo

function E:ApplyCamera(modeName, silent)
	local mode = self.cameraModes[modeName] or self.cameraModes.explore
	allowActionCam()
	for k, v in pairs(mode.cvars) do HP:SetCVarTracked(k, v) end
	if not InCombatLockdown() and not IsMounted() then zoomTo(mode.zoom) end
	if not silent then HP:Toast("Camera: " .. mode.label) end
end

function E:CycleCamera()
	local cur = HP.db.explore.cameraMode
	local idx = 1
	for i, k in ipairs(self.cameraOrder) do if k == cur then idx = i end end
	local nextMode = self.cameraOrder[idx % #self.cameraOrder + 1]
	HP:Set("explore.cameraMode", nextMode)
end

-- Context reactions: pull back for fights and mounts, return after.
local savedZoom
local function contextZoom(reason, distance)
	if not GetCameraZoom then return end
	if distance then
		savedZoom = savedZoom or GetCameraZoom()
		if GetCameraZoom() < distance then zoomTo(distance) end
	elseif savedZoom then
		zoomTo(savedZoom)
		savedZoom = nil
	end
end

---------------------------------------------------------------------------
-- Immersion: fade the HUD while exploring calmly
---------------------------------------------------------------------------
local HUD_FRAMES = {
	"PlayerFrame", "PetFrame", "MinimapCluster", "BuffFrame", "DebuffFrame", "ObjectiveTrackerFrame",
	"QuestWatchFrame", "MicroMenuContainer", "MicroButtonAndBagsBar", "BagsBar", "MainActionBar", "MainMenuBar",
	"MultiBarBottomLeft", "MultiBarBottomRight", "MultiBarRight", "MultiBarLeft", "StanceBar", "PetActionBar",
	"StatusTrackingBarManager", "HearthpadCrossbar",
}
local calmSince, faded = 0, false

local function wantsHUD()
	if InCombatLockdown() or UnitAffectingCombat("player") then return true end
	if UnitExists("target") then return true end
	if IsShiftKeyDown() or IsControlKeyDown() then return true end -- holding a trigger = peek
	if HP.Input:Top() then return true end
	if SpellIsTargeting and SpellIsTargeting() then return true end
	if UnitCastingInfo("player") or UnitChannelInfo("player") then return true end
	local cur, max = HP.Readable(UnitHealth("player")), HP.Readable(UnitHealthMax("player"))
	if cur and max and max > 0 and cur / max < 0.95 then return true end
	return false
end

local function setHUDAlpha(alpha)
	for _, name in ipairs(HUD_FRAMES) do
		local f = _G[name]
		if f and f.SetAlpha then T.FadeTo(f, alpha) end
	end
end

local function immersionTick()
	-- Conversations are cinematic: the HUD steps aside entirely.
	if HP.Dialogue and HP.Dialogue.active then
		if not faded then faded = true setHUDAlpha(0) end
		calmSince = 0
		return
	end
	if not HP.db.explore.immersion then
		if faded then faded = false setHUDAlpha(1) end
		return
	end
	if wantsHUD() then
		calmSince = GetTime()
		if faded then faded = false setHUDAlpha(1) end
	elseif not faded and GetTime() - calmSince >= (HP.db.explore.immersionDelay or 4) then
		faded = true
		setHUDAlpha(HP.db.explore.immersionAlpha or 0)
	end
end

---------------------------------------------------------------------------
-- Compass: cardinal strip + direction and distance to your waypoint / tracked quest
---------------------------------------------------------------------------
local compass
local COMPASS_W, PX_PER_RAD = 420, 420 / (math.pi * 0.9) -- shows ~160 degrees
local CARDINALS = { { "N", 0 }, { "NW", math.pi / 4 }, { "W", math.pi / 2 }, { "SW", 3 * math.pi / 4 },
	{ "S", math.pi }, { "SE", -3 * math.pi / 4 }, { "E", -math.pi / 2 }, { "NE", -math.pi / 4 } }

local function wrap(a)
	while a > math.pi do a = a - 2 * math.pi end
	while a <= -math.pi do a = a + 2 * math.pi end
	return a
end

local function waypointOnMap(mapID)
	-- 1) player-placed pin
	if C_Map.HasUserWaypoint and C_Map.HasUserWaypoint() then
		local p = C_Map.GetUserWaypoint()
		if p and p.uiMapID == mapID and p.position then return p.position.x, p.position.y, "Waypoint" end
	end
	-- 2) super-tracked quest
	if C_SuperTrack and C_SuperTrack.GetSuperTrackedQuestID then
		local q = C_SuperTrack.GetSuperTrackedQuestID()
		if q and q > 0 and C_QuestLog.GetNextWaypoint then
			local ok, wMap, x, y = pcall(C_QuestLog.GetNextWaypoint, q)
			if ok and wMap == mapID and x then
				return x, y, (C_QuestLog.GetTitleForQuestID and C_QuestLog.GetTitleForQuestID(q)) or "Quest"
			end
		end
	end
end

local function updateCompass()
	if not compass:IsShown() then return end
	local facing = HP.Readable(GetPlayerFacing and GetPlayerFacing())
	if not facing then compass.strip:SetAlpha(0) return end
	compass.strip:SetAlpha(1)
	for i, c in ipairs(CARDINALS) do
		local rel = wrap(c[2] - facing)
		local fs = compass.marks[i]
		local x = -rel * PX_PER_RAD
		if math.abs(x) < COMPASS_W / 2 - 10 then
			fs:SetPoint("CENTER", compass, "CENTER", x, 0)
			fs:SetAlpha(1 - math.abs(x) / (COMPASS_W / 2) * 0.7)
			fs:Show()
		else
			fs:Hide()
		end
	end

	compass.pin:Hide()
	compass.dist:SetText("")
	local mapID = C_Map.GetBestMapForUnit("player")
	local pos = mapID and C_Map.GetPlayerMapPosition(mapID, "player")
	if not pos then return end
	local px, py = pos:GetXY()
	local tx, ty, label = waypointOnMap(mapID)
	if not tx then return end
	local w, h = C_Map.GetMapWorldSize(mapID)
	if not w or w == 0 then return end
	local dE, dS = (tx - px) * w, (ty - py) * h        -- yards east / south
	local bearing = math.atan2(-dE, -dS)                -- CCW from north, like GetPlayerFacing
	local rel = wrap(bearing - facing)
	local x = HP.Clamp(-rel * PX_PER_RAD, -COMPASS_W / 2 + 8, COMPASS_W / 2 - 8)
	compass.pin:SetPoint("CENTER", compass, "CENTER", x, 0)
	compass.pin:Show()
	local yards = math.floor(math.sqrt(dE * dE + dS * dS) + 0.5)
	compass.dist:SetText(("%s · %d yd"):format(label or "", yards))
end

local function buildCompass()
	compass = CreateFrame("Frame", "HearthpadCompass", UIParent)
	compass:SetSize(COMPASS_W, 28)
	compass:SetPoint("TOP", 0, -10)
	compass:SetFrameStrata("LOW")
	-- Background fades out toward both ends.
	for i, side in ipairs({ "LEFT", "RIGHT" }) do
		local bg = compass:CreateTexture(nil, "BACKGROUND")
		bg:SetPoint("TOP") bg:SetPoint("BOTTOM") bg:SetPoint(side)
		bg:SetWidth(COMPASS_W / 2)
		bg:SetColorTexture(1, 1, 1, 1)
		if bg.SetGradient and CreateColor then
			local solid, clear = CreateColor(0, 0, 0, 0.5), CreateColor(0, 0, 0, 0)
			if i == 1 then bg:SetGradient("HORIZONTAL", clear, solid) else bg:SetGradient("HORIZONTAL", solid, clear) end
		else
			bg:SetColorTexture(0, 0, 0, 0.35)
		end
	end
	compass.strip = CreateFrame("Frame", nil, compass)
	compass.strip:SetAllPoints()
	compass.marks = {}
	for i, c in ipairs(CARDINALS) do
		local fs = T.Text(compass.strip, #c[1] == 1 and 16 or 12, #c[1] == 1 and T.color.accent or T.color.dim, "OUTLINE")
		fs:SetText(c[1])
		compass.marks[i] = fs
	end
	local center = compass:CreateTexture(nil, "OVERLAY")
	center:SetSize(2, 10)
	center:SetPoint("BOTTOM", 0, 0)
	center:SetColorTexture(1, 1, 1, 0.8)
	compass.pin = compass:CreateTexture(nil, "OVERLAY", nil, 3)
	compass.pin:SetSize(11, 11)
	compass.pin:SetColorTexture(1, 0.82, 0.38, 1)
	compass.pin:SetRotation(math.pi / 4) -- gold diamond
	compass.dist = T.Text(compass, 12, T.color.text, "OUTLINE")
	compass.dist:SetPoint("TOP", compass, "BOTTOM", 0, -2)
	C_Timer.NewTicker(1 / 30, updateCompass)
end

---------------------------------------------------------------------------
-- Zone cards: cinematic title when you enter a new area
---------------------------------------------------------------------------
local card
local function buildCard()
	card = CreateFrame("Frame", nil, UIParent)
	card:SetSize(700, 120)
	card:SetPoint("TOP", 0, -150)
	card:SetFrameStrata("HIGH")
	card.title = T.Text(card, 38, T.color.accent, "OUTLINE")
	card.title:SetPoint("TOP")
	card.rule = card:CreateTexture(nil, "ARTWORK")
	card.rule:SetSize(320, 1)
	card.rule:SetPoint("TOP", card.title, "BOTTOM", 0, -8)
	card.rule:SetColorTexture(1, 0.82, 0.38, 0.6)
	card.sub = T.Text(card, 18, T.color.text, "OUTLINE")
	card.sub:SetPoint("TOP", card.rule, "BOTTOM", 0, -8)
	card.pvp = T.Text(card, 14, T.color.dim, "OUTLINE")
	card.pvp:SetPoint("TOP", card.sub, "BOTTOM", 0, -6)
	card:SetAlpha(0)
end

local lastZone
local function showZoneCard(force)
	if not HP.db.explore.zoneCards then return end
	local zone, sub = GetZoneText(), GetSubZoneText()
	if not force and zone == lastZone then return end
	lastZone = zone
	card.title:SetText(zone or "")
	card.sub:SetText(sub ~= zone and sub or "")
	local pvpType = GetZonePVPInfo and GetZonePVPInfo()
	local label = ({ sanctuary = "Sanctuary", friendly = "Friendly territory", hostile = "Hostile territory",
		contested = "Contested territory", combat = "Combat zone" })[pvpType or ""] or ""
	card.pvp:SetText(label)
	card:SetAlpha(0)
	T.FadeTo(card, 1)
	card.serial = (card.serial or 0) + 1
	local s = card.serial
	C_Timer.After(3.5, function() if card.serial == s then T.FadeTo(card, 0) end end)
end

local function suppressBlizzardZoneText(on)
	for _, name in ipairs({ "ZoneTextFrame", "SubZoneTextFrame" }) do
		local f = _G[name]
		if f then f:SetAlpha(on and 0 or 1) end
	end
end

---------------------------------------------------------------------------
function E:Init()
	HP:RegisterOption({ path = "explore.cameraMode", label = "Camera style", section = "Exploration", type = "choice",
		values = { { "classic", "Classic" }, { "explore", "Explore" }, { "cinematic", "Cinematic" } } })
	HP:RegisterOption({ path = "explore.combatCamera", label = "Pull camera back in combat", section = "Exploration", type = "toggle" })
	HP:RegisterOption({ path = "explore.mountedZoom", label = "Wider camera when mounted", section = "Exploration", type = "toggle" })
	HP:RegisterOption({ path = "explore.compass", label = "Compass & waypoint", section = "Exploration", type = "toggle" })
	HP:RegisterOption({ path = "explore.zoneCards", label = "Cinematic zone titles", section = "Exploration", type = "toggle" })
	HP:RegisterOption({ path = "explore.immersion", label = "Fade HUD while exploring", section = "Exploration", type = "toggle",
		desc = "Hold L2 or R2 to peek. Combat, targets and damage bring it back instantly." })
	HP:RegisterOption({ path = "explore.immersionAlpha", label = "Faded HUD opacity", section = "Exploration", type = "range", min = 0, max = 0.6, step = 0.1 })

	buildCompass()
	buildCard()
	compass:SetShown(HP.db.explore.compass)
	suppressBlizzardZoneText(HP.db.explore.zoneCards)

	HP:On("PLAYER_ENTERING_WORLD", function(isLogin, isReload)
		E:ApplyCamera(HP.db.explore.cameraMode, true)
		if isLogin then showZoneCard(true) end
	end)
	HP:On("ZONE_CHANGED_NEW_AREA", function() showZoneCard() end)

	HP:On("PLAYER_REGEN_DISABLED", function()
		if HP.db.explore.combatCamera then
			HP:SetCVarTracked("test_cameraTargetFocusEnemyEnable", 1)
			contextZoom("combat", 14)
		end
	end)
	HP:On("PLAYER_REGEN_ENABLED", function()
		if HP.db.explore.combatCamera then
			local mode = E.cameraModes[HP.db.explore.cameraMode]
			pcall(SetCVar, "test_cameraTargetFocusEnemyEnable", mode and mode.cvars.test_cameraTargetFocusEnemyEnable or 0)
			if not IsMounted() then contextZoom("combat", nil) end
		end
	end)
	HP:On("PLAYER_MOUNT_DISPLAY_CHANGED", function()
		if not HP.db.explore.mountedZoom or InCombatLockdown() then return end
		if IsMounted() then contextZoom("mount", 18) else contextZoom("mount", nil) end
	end)

	C_Timer.NewTicker(0.25, immersionTick)

	HP:On("HP_SETTING_CHANGED", function(path, value)
		if path == "explore.cameraMode" then E:ApplyCamera(value)
		elseif path == "explore.compass" then compass:SetShown(value)
		elseif path == "explore.zoneCards" then suppressBlizzardZoneText(value)
		elseif path == "explore.immersion" and not value then faded = false setHUDAlpha(1) end
	end)
end
