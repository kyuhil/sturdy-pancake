-- Hearthpad: crossbar HUD. Two diamonds (D-pad left, face right) show exactly what each
-- button does on the layer you're holding. Hold L2/R2 and the HUD swaps instantly.
-- Pure display: it reads Blizzard's action slots and never performs actions itself.
local _, HP = ...
local X = HP:NewModule("Crossbar")
local T = HP.Theme

local SLOT = 54
local GAP = 6
-- Diamond offsets (relative to cluster centre): up, right, down, left
local DIAMOND = {
	PAD4 = { 0, 1 }, PAD2 = { 1, 0 }, PAD1 = { 0, -1 }, PAD3 = { -1, 0 },
	PADDUP = { 0, 1 }, PADDRIGHT = { 1, 0 }, PADDDOWN = { 0, -1 }, PADDLEFT = { -1, 0 },
}
local FACE = { "PAD4", "PAD2", "PAD1", "PAD3" }
local DPAD = { "PADDUP", "PADDRIGHT", "PADDDOWN", "PADDLEFT" }

local STATIC_ICONS = {
	JUMP = "Interface\\Icons\\Ability_Rogue_Sprint",
	INTERACTTARGET = "Interface\\Icons\\INV_Misc_Bag_08",
}

local root, slots, layerLabel, peeks

local function readCooldown(slot)
	if C_ActionBar and C_ActionBar.GetActionCooldown then
		local ok, info = pcall(C_ActionBar.GetActionCooldown, slot)
		if ok and type(info) == "table" then
			return HP.Readable(info.startTime), HP.Readable(info.duration)
		end
	end
	if GetActionCooldown then
		local ok, s, d = pcall(GetActionCooldown, slot)
		if ok then return HP.Readable(s), HP.Readable(d) end
	end
end

local function makeSlot(parent, key)
	local f = CreateFrame("Frame", nil, parent)
	f:SetSize(SLOT, SLOT)
	f.key = key

	f.bg = f:CreateTexture(nil, "BACKGROUND")
	f.bg:SetAllPoints()
	f.bg:SetColorTexture(0, 0, 0, 0.55)

	f.icon = f:CreateTexture(nil, "ARTWORK")
	f.icon:SetPoint("TOPLEFT", 3, -3)
	f.icon:SetPoint("BOTTOMRIGHT", -3, 3)
	f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

	f.cd = CreateFrame("Cooldown", nil, f, "CooldownFrameTemplate")
	f.cd:SetAllPoints(f.icon)
	f.cd:SetDrawEdge(false)

	f.border = f:CreateTexture(nil, "OVERLAY")
	f.border:SetPoint("TOPLEFT", -1, 1)
	f.border:SetPoint("BOTTOMRIGHT", 1, -1)
	f.border:SetColorTexture(1, 1, 1, 0)

	f.flash = f:CreateTexture(nil, "OVERLAY", nil, 2)
	f.flash:SetAllPoints(f.icon)
	f.flash:SetColorTexture(1, 0.9, 0.6, 0)

	f.count = T.Text(f, 13, T.color.text, "OUTLINE")
	f.count:SetPoint("BOTTOMRIGHT", -3, 3)

	f.caption = T.Text(f, 11, T.color.dim, "OUTLINE")
	f.caption:SetPoint("TOP", f, "BOTTOM", 0, -1)
	f.caption:SetWidth(SLOT + 20)
	f.caption:SetWordWrap(false)

	f.glyph = T.Glyph(f, key, 18)
	f.glyph:SetPoint("CENTER", f, "BOTTOMLEFT", 4, 4)
	f.glyph:SetFrameLevel(f.cd:GetFrameLevel() + 2)

	-- press pulse
	f.pulse = f:CreateAnimationGroup()
	local a = f.pulse:CreateAnimation("Alpha")
	a:SetTarget(f.flash) a:SetFromAlpha(0.55) a:SetToAlpha(0) a:SetDuration(0.22)
	local s = f.pulse:CreateAnimation("Scale")
	if s.SetScaleFrom then
		s:SetScaleFrom(0.9, 0.9) s:SetScaleTo(1, 1)
	else
		s:SetScale(1.08, 1.08)
	end
	s:SetDuration(0.16) s:SetOrigin("CENTER", 0, 0)
	return f
end

local function cluster(parent, keys, anchor, x)
	local c = CreateFrame("Frame", nil, parent)
	c:SetSize(SLOT * 3 + GAP * 2, SLOT * 3 + GAP * 2)
	c:SetPoint("BOTTOM", parent, anchor, x, 0)
	for _, key in ipairs(keys) do
		local s = makeSlot(c, key)
		local o = DIAMOND[key]
		s:SetPoint("CENTER", c, "CENTER", o[1] * (SLOT + GAP), o[2] * (SLOT + GAP))
		slots[key] = s
	end
	return c
end

local function updateSlot(s, layerIndex)
	local B = HP.Bindings
	local cmd = B:CommandFor(layerIndex, s.key)
	s.cmd = cmd
	s.slot = nil
	s.count:SetText("")
	s.caption:SetText("")
	s.cd:Clear()
	if not cmd then s.icon:SetTexture(nil) return end

	if STATIC_ICONS[cmd] then
		s.icon:SetTexture(STATIC_ICONS[cmd])
		s.icon:SetDesaturated(false)
		s.icon:SetVertexColor(1, 1, 1)
		local label = B.labels[cmd]
		if cmd == "INTERACTTARGET" then
			local name = UnitExists("softinteract") and HP.Readable(UnitName("softinteract"))
			label = name or label
		end
		s.caption:SetText(label or "")
		return
	end

	local slot = B:SlotForCommand(cmd)
	s.slot = slot
	local tex = slot and HP.Readable(GetActionTexture(slot))
	s.icon:SetTexture(tex)
	if not tex then return end

	local start, dur = readCooldown(slot)
	if start and dur and dur > 1.5 then s.cd:SetCooldown(start, dur) end

	local usable, noMana = nil, nil
	local ok, u, n = pcall(IsUsableAction, slot)
	if ok then usable, noMana = HP.Readable(u), HP.Readable(n) end
	local inRange = nil
	local okR, r = pcall(IsActionInRange, slot)
	if okR then inRange = HP.Readable(r) end

	if inRange == false then s.icon:SetVertexColor(0.95, 0.35, 0.3)
	elseif noMana then s.icon:SetVertexColor(0.4, 0.5, 1)
	else s.icon:SetVertexColor(1, 1, 1) end
	s.icon:SetDesaturated(usable == false and not noMana)

	local okC, count = pcall(GetActionCount, slot)
	count = okC and HP.Readable(count)
	if count and count > 1 then s.count:SetText(count) end
end

function X:Refresh()
	if not root or not root:IsShown() then return end
	local li = HP.Bindings:ActiveLayer()
	self.layer = li
	for _, s in pairs(slots) do updateSlot(s, li) end
	local layer = HP.Bindings.layers[li]
	local c = layer.color
	layerLabel:SetText(layer.label)
	layerLabel:SetTextColor(c[1], c[2], c[3])
	for _, s in pairs(slots) do s.border:SetColorTexture(c[1], c[2], c[3], li > 1 and 0.55 or 0) end
	for i, p in ipairs(peeks) do p:SetAlpha(i == li and 1 or 0.35) end
end

function X:Build()
	slots, peeks = {}, {}
	root = CreateFrame("Frame", "HearthpadCrossbar", UIParent)
	root:SetSize(560, SLOT * 3 + GAP * 2 + 24)
	root:SetPoint("BOTTOM", 0, 26)
	root:SetFrameStrata("MEDIUM")
	root:SetScale(HP.db.hud.scale or 1)

	cluster(root, DPAD, "BOTTOMLEFT", SLOT * 1.5 + GAP + 10)
	cluster(root, FACE, "BOTTOMRIGHT", -(SLOT * 1.5 + GAP + 10))

	layerLabel = T.Text(root, 20, T.color.text, "OUTLINE")
	layerLabel:SetPoint("BOTTOM", 0, SLOT + GAP)

	-- Layer pips: which of the four layers is live, always visible.
	local pipRow = CreateFrame("Frame", nil, root)
	pipRow:SetSize(4 * 16, 8)
	pipRow:SetPoint("BOTTOM", 0, SLOT * 0.5)
	for i, layer in ipairs(HP.Bindings.layers) do
		local p = pipRow:CreateTexture(nil, "OVERLAY")
		p:SetSize(12, 6)
		p:SetPoint("LEFT", (i - 1) * 16, 0)
		local c = layer.color
		p:SetColorTexture(c[1], c[2], c[3], 1)
		peeks[i] = p
	end
end

function X:SetShown(shown)
	if not root then return end
	root:SetShown(shown)
	if shown then self:Refresh() end
end

function X:Frame() return root end

function X:Init()
	HP:RegisterOption({ path = "hud.crossbar", label = "Crossbar HUD", section = "HUD", type = "toggle" })
	HP:RegisterOption({ path = "hud.scale", label = "HUD scale", section = "HUD", type = "range", min = 0.7, max = 1.4, step = 0.05 })

	self:Build()
	self:SetShown(HP.db.hud.crossbar and HP.db.controls.enabled)

	local function refresh() X:Refresh() end
	for _, e in ipairs({ "ACTIONBAR_SLOT_CHANGED", "ACTIONBAR_UPDATE_COOLDOWN", "ACTIONBAR_UPDATE_USABLE",
		"ACTIONBAR_UPDATE_STATE", "ACTIONBAR_PAGE_CHANGED", "UPDATE_BONUS_ACTIONBAR", "UPDATE_SHAPESHIFT_FORM",
		"SPELL_UPDATE_COOLDOWN", "SPELL_UPDATE_USABLE", "PLAYER_TARGET_CHANGED", "PLAYER_SOFT_INTERACT_CHANGED",
		"UNIT_POWER_FREQUENT", "BAG_UPDATE_DELAYED", "HP_BINDINGS_APPLIED", "PLAYER_ENTERING_WORLD" }) do
		HP:On(e, refresh)
	end

	-- Layer switches must feel instant: react to modifier changes, plus a light poll
	-- as a safety net because emulated modifiers may not always raise the event.
	HP:On("MODIFIER_STATE_CHANGED", refresh)
	C_Timer.NewTicker(0.05, function()
		if root:IsShown() and HP.Bindings:ActiveLayer() ~= X.layer then X:Refresh() end
	end)
	-- Range colouring
	C_Timer.NewTicker(0.25, function() if root:IsShown() then X:Refresh() end end)

	-- Press feedback from live pad state
	HP.Gamepad:Acquire()
	HP:On("HP_PAD_DOWN", function(name)
		local s = slots[name]
		if s and root:IsShown() and not HP.Input:IsCapturing() then
			s.pulse:Stop()
			s.pulse:Play()
		end
	end)

	HP:On("HP_SETTING_CHANGED", function(path, value)
		if path == "hud.scale" then root:SetScale(value) end
		if path == "hud.crossbar" or path == "controls.enabled" then
			X:SetShown(HP.db.hud.crossbar and HP.db.controls.enabled)
		end
	end)
end
