-- Hearthpad: input contexts. When a Hearthpad surface (Hub, dialogue, menu navigator)
-- takes focus it pushes a context; the context's keys are bound with *priority* override
-- bindings to hidden buttons, so the world bindings underneath are untouched and come back
-- the moment the context pops. Binding changes are protected, so contexts only open
-- out of combat; callers fall back to Blizzard's own UI when Push returns false.
local _, HP = ...
local I = HP:NewModule("Input")

I.keys = {
	"PAD1", "PAD2", "PAD3", "PAD4",
	"PADDUP", "PADDDOWN", "PADDLEFT", "PADDRIGHT",
	"PADLSHOULDER", "PADRSHOULDER", "PADBACK", "PADFORWARD",
}
local MODIFIER_PREFIXES = { "", "SHIFT-", "CTRL-", "CTRL-SHIFT-" }
-- Keys that auto-repeat while held (list navigation)
local REPEATS = { PADDUP = true, PADDDOWN = true, PADDLEFT = true, PADDRIGHT = true }

local owner = CreateFrame("Frame", "HearthpadInputOwner", UIParent)
local stack = {}
local repeatTicker

local function stopRepeat()
	if repeatTicker then repeatTicker:Cancel() repeatTicker = nil end
end

local function dispatch(key)
	local ctx = stack[#stack]
	if ctx and ctx.OnKey then
		local ok, err = pcall(ctx.OnKey, ctx, key)
		if not ok then geterrorhandler()(err) end
	end
end

for _, key in ipairs(I.keys) do
	local b = CreateFrame("Button", "HearthpadKey_" .. key, UIParent)
	b:Hide()
	b:RegisterForClicks("AnyDown", "AnyUp")
	b:SetScript("OnClick", function(_, _, isDown)
		if isDown == false then
			stopRepeat()
			return
		end
		dispatch(key)
		if REPEATS[key] and isDown == true then
			stopRepeat()
			local first = true
			repeatTicker = C_Timer.NewTicker(0.09, function()
				if first then first = false return end -- small initial delay
				dispatch(key)
			end)
		end
	end)
end

-- Secure proxy: lets "A" click a real Blizzard button (bag items, talents, vendor
-- rows) as a genuine hardware click, which addon code cannot do on its own.
local proxy = CreateFrame("Button", "HearthpadClickProxy", UIParent, "SecureActionButtonTemplate")
proxy:RegisterForClicks("AnyDown")
proxy:SetAttribute("type", "click")
proxy:HookScript("OnClick", function(_, button)
	local ctx = stack[#stack]
	if ctx and ctx.OnProxyClick then pcall(ctx.OnProxyClick, ctx, button) end
end)
I.proxy = proxy

function I:SetClickTarget(frame)
	if InCombatLockdown() then return false end
	proxy:SetAttribute("clickbutton", frame)
	return true
end

local function setCursor(enabled)
	if SetGamePadCursorControl then pcall(SetGamePadCursorControl, enabled) end
end

local function apply()
	if InCombatLockdown() then
		HP:AfterCombat("input-apply", apply)
		return
	end
	ClearOverrideBindings(owner)
	local ctx = stack[#stack]
	if not ctx then
		HP:Fire("HP_INPUT_RELEASED")
		return
	end
	setCursor(false)
	-- Bind every modifier variant too: the triggers act as Shift/Ctrl, and a held trigger
	-- must never leak a face-button press through to a crossbar action while in a menu.
	for _, prefix in ipairs(MODIFIER_PREFIXES) do
		for _, key in ipairs(I.keys) do
			if not (ctx.passthrough and ctx.passthrough[key]) then
				SetOverrideBindingClick(owner, true, prefix .. key, "HearthpadKey_" .. key)
			end
		end
		if ctx.useClickProxy then
			SetOverrideBindingClick(owner, true, prefix .. "PAD1", "HearthpadClickProxy", "LeftButton")
			SetOverrideBindingClick(owner, true, prefix .. "PAD3", "HearthpadClickProxy", "RightButton")
		end
	end
	HP:Fire("HP_INPUT_CAPTURED", ctx.name)
end

function I:Push(ctx)
	if InCombatLockdown() then return false end
	for i = #stack, 1, -1 do
		if stack[i] == ctx then table.remove(stack, i) end
	end
	stack[#stack + 1] = ctx
	apply()
	return true
end

function I:Pop(ctx)
	local removed = false
	for i = #stack, 1, -1 do
		if stack[i] == ctx then table.remove(stack, i) removed = true end
	end
	if removed then
		stopRepeat()
		apply()
	end
end

function I:Top() return stack[#stack] end
function I:IsActive(ctx) return stack[#stack] == ctx end
function I:Refresh() apply() end

-- Combat always wins: protected changes are still allowed inside PLAYER_REGEN_DISABLED,
-- so we hand every button back to the world bindings before lockdown begins, and restore
-- the open context once combat ends.
HP:On("PLAYER_REGEN_DISABLED", function()
	stopRepeat()
	if #stack == 0 then return end
	pcall(ClearOverrideBindings, owner)
	local ctx = stack[#stack]
	if ctx and ctx.OnCombat then pcall(ctx.OnCombat, ctx) end
end)
HP:On("PLAYER_REGEN_ENABLED", function()
	if #stack > 0 then apply() end
end)

function I:IsCapturing()
	return #stack > 0 and not InCombatLockdown()
end
