-- Hearthpad: combat presentation — screen-edge vignettes and haptics that make fights
-- read clearly on a small screen without adding HUD clutter.
-- Health reads go through HP.Readable: where Forever hides a value as secret, the
-- matching effect simply stays off rather than guessing.
local _, HP = ...
local C = HP:NewModule("Combat")

local edge, hurt, lastHeartbeat = nil, nil, 0

local function makeVignette(r, g, b)
	local f = CreateFrame("Frame", nil, UIParent)
	f:SetAllPoints(UIParent)
	f:SetFrameStrata("BACKGROUND")
	f:EnableMouse(false)
	local function side(p1, p2, horizontal)
		local t = f:CreateTexture(nil, "OVERLAY")
		t:SetColorTexture(1, 1, 1, 1)
		t:SetPoint(p1) t:SetPoint(p2)
		if horizontal then t:SetHeight(140) else t:SetWidth(180) end
		return t
	end
	local sides = {
		{ side("TOPLEFT", "TOPRIGHT", true), "VERTICAL", false },
		{ side("BOTTOMLEFT", "BOTTOMRIGHT", true), "VERTICAL", true },
		{ side("TOPLEFT", "BOTTOMLEFT", false), "HORIZONTAL", true },
		{ side("TOPRIGHT", "BOTTOMRIGHT", false), "HORIZONTAL", false },
	}
	for _, s in ipairs(sides) do
		local tex, dir, solidFirst = s[1], s[2], s[3]
		if tex.SetGradient and CreateColor then
			local solid, clear = CreateColor(r, g, b, 0.55), CreateColor(r, g, b, 0)
			if solidFirst then tex:SetGradient(dir, solid, clear) else tex:SetGradient(dir, clear, solid) end
		else
			tex:SetColorTexture(r, g, b, 0.12)
		end
	end
	f:SetAlpha(0)
	return f
end

local function flashEdge(alpha, hold)
	if not HP.db.combat.vignette then return end
	edge:SetAlpha(alpha)
	C_Timer.After(hold or 0.15, function() HP.Theme.FadeTo(edge, 0) end)
end

local function playerHealthPct()
	local cur = HP.Readable(UnitHealth("player"))
	local max = HP.Readable(UnitHealthMax("player"))
	if cur and max and max > 0 then return cur / max end
end

local function updateHurt()
	if not HP.db.combat.lowHealth then hurt:SetAlpha(0) return end
	local pct = playerHealthPct()
	if not pct or UnitIsDeadOrGhost("player") then hurt:SetAlpha(0) return end
	local a = pct < 0.4 and HP.Clamp((0.4 - pct) / 0.3, 0, 1) or 0
	hurt:SetAlpha(a)
	if pct < 0.2 and GetTime() - lastHeartbeat > 1.1 then
		lastHeartbeat = GetTime()
		HP.Gamepad:Rumble("heartbeat")
	end
end

function C:Init()
	HP:RegisterOption({ path = "combat.vignette", label = "Combat edge flashes", section = "Combat", type = "toggle" })
	HP:RegisterOption({ path = "combat.lowHealth", label = "Low-health vignette & heartbeat", section = "Combat", type = "toggle" })

	edge = makeVignette(1, 0.45, 0.2)
	hurt = makeVignette(0.75, 0.02, 0.02)

	HP:On("PLAYER_REGEN_DISABLED", function()
		flashEdge(0.7, 0.2)
		HP.Gamepad:Rumble("light")
	end)
	HP:On("PLAYER_REGEN_ENABLED", function() HP.Gamepad:Rumble("tick") end)
	HP:On("UNIT_HEALTH", function(unit) if unit == "player" then updateHurt() end end)
	HP:On("UNIT_MAXHEALTH", function(unit) if unit == "player" then updateHurt() end end)
	HP:On("PLAYER_DEAD", function() hurt:SetAlpha(0) HP.Gamepad:Rumble("heavy") end)
	HP:On("PLAYER_LEVEL_UP", function() HP.Gamepad:Rumble("levelup") end)
	HP:On("LOSS_OF_CONTROL_ADDED", function() flashEdge(0.9, 0.35) HP.Gamepad:Rumble("heavy") end)

	HP:On("PLAYER_TARGET_CHANGED", function()
		if UnitExists("target") and UnitCanAttack("player", "target") then HP.Gamepad:Rumble("tick") end
	end)
	HP:On("UNIT_SPELLCAST_INTERRUPTED", function(unit)
		if unit == "player" then HP.Gamepad:Rumble("medium") end
	end)
	HP:On("UNIT_SPELLCAST_SUCCEEDED", function(unit)
		if unit == "player" and HP.db.haptics.onCast then HP.Gamepad:Rumble("tick") end
	end)
end
