-- Hearthpad: core runtime — event bus, modules, saved settings, combat queue, secret-value guards.
local ADDON, HP = ...
_G.Hearthpad = HP

HP.name = ADDON
HP.version = (C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(ADDON, "Version")) or "dev"

---------------------------------------------------------------------------
-- Defaults. Every user-facing option lives here and is exposed in the Hub.
---------------------------------------------------------------------------
HP.defaults = {
	firstRunDone = false,
	controls = {
		enabled = true,         -- apply the Hearthpad crossbar layout as override bindings
		swapJumpInteract = false,
	},
	hud = {
		crossbar = true,
		scale = 1.0,
		showInactiveLayers = true, -- small "peek" of the other layers
	},
	nav = {
		enabled = true,         -- D-pad snap navigation in Blizzard panels
		tooltips = true,
	},
	dialogue = {
		enabled = true,
		typewriter = true,
		typeSpeed = 60,         -- characters per second
		camera = true,
		-- When a voiceover addon (Spoken etc.) is running and shows its own subtitles:
		--   "compact" = it shows the words; Hearthpad shows portrait, choices, rewards, controls
		--   "full"    = Hearthpad shows the text too
		--   "handoff" = Hearthpad stays out of conversations; Blizzard's window + D-pad navigation
		voiceMode = "compact",
		tts = false,            -- built-in text-to-speech fallback when no voice addon is present
		autoSpeak = false,
	},
	explore = {
		cameraMode = "explore", -- "classic" | "explore" | "cinematic"
		combatCamera = true,
		mountedZoom = true,
		compass = true,
		zoneCards = true,
		immersion = true,       -- fade HUD while calmly exploring
		immersionAlpha = 0.0,
		immersionDelay = 4,
	},
	combat = {
		vignette = true,
		lowHealth = true,
	},
	haptics = {
		enabled = true,
		strength = 0.8,
		onCast = false,
	},
}

---------------------------------------------------------------------------
-- Utilities
---------------------------------------------------------------------------
local function copyDefaults(src, dst)
	for k, v in pairs(src) do
		if type(v) == "table" then
			if type(dst[k]) ~= "table" then dst[k] = {} end
			copyDefaults(v, dst[k])
		elseif dst[k] == nil then
			dst[k] = v
		end
	end
	return dst
end

-- Dotted-path access into the DB: HP:Get("explore.compass")
function HP:Get(path)
	local node = self.db
	for part in path:gmatch("[^%.]+") do
		if type(node) ~= "table" then return nil end
		node = node[part]
	end
	return node
end

function HP:Set(path, value)
	local node, last = self.db, nil
	local parts = {}
	for part in path:gmatch("[^%.]+") do parts[#parts + 1] = part end
	for i = 1, #parts - 1 do
		node[parts[i]] = node[parts[i]] or {}
		node = node[parts[i]]
	end
	last = parts[#parts]
	node[last] = value
	self:Fire("HP_SETTING_CHANGED", path, value)
end

-- Forever inherits Midnight's "secret values". Anything combat-related may be
-- unreadable to addon code; every feature that reads such data goes through this.
local issecret = _G.issecretvalue or function() return false end
function HP.Readable(v)
	if v == nil or issecret(v) then return nil end
	return v
end

function HP.SafeCall(fn, ...)
	if type(fn) ~= "function" then return false end
	return pcall(fn, ...)
end

function HP.Clamp(v, lo, hi) if v < lo then return lo elseif v > hi then return hi end return v end
function HP.Lerp(a, b, t) return a + (b - a) * t end

function HP:Print(...)
	print("|cffffd060Hearthpad|r:", ...)
end

function HP:Debug(...)
	if self.db and self.db.debug then self:Print("|cff888888", ..., "|r") end
end

---------------------------------------------------------------------------
-- Event bus. Real WoW events and internal "HP_" messages share one API.
---------------------------------------------------------------------------
local bus = CreateFrame("Frame")
local handlers = {}

function HP:On(event, fn)
	if not handlers[event] then
		handlers[event] = {}
		if not event:find("^HP_") then
			-- Some events differ between game types; never hard-fail on one.
			pcall(bus.RegisterEvent, bus, event)
		end
	end
	local list = handlers[event]
	list[#list + 1] = fn
end

function HP:Fire(event, ...)
	local list = handlers[event]
	if not list then return end
	for i = 1, #list do
		local ok, err = pcall(list[i], ...)
		if not ok then geterrorhandler()(err) end
	end
end

bus:SetScript("OnEvent", function(_, event, ...) HP:Fire(event, ...) end)

---------------------------------------------------------------------------
-- Combat lockdown queue: protected work (bindings, secure attributes) waits.
---------------------------------------------------------------------------
local pending, pendingOrder = {}, {}

function HP:AfterCombat(key, fn)
	if not InCombatLockdown() then fn() return true end
	if not pending[key] then pendingOrder[#pendingOrder + 1] = key end
	pending[key] = fn
	return false
end

HP:On("PLAYER_REGEN_ENABLED", function()
	local order = pendingOrder
	pendingOrder = {}
	for _, key in ipairs(order) do
		local fn = pending[key]
		pending[key] = nil
		if fn then
			local ok, err = pcall(fn)
			if not ok then geterrorhandler()(err) end
		end
	end
end)

---------------------------------------------------------------------------
-- Modules and the options registry (rendered by the Hub's Settings page)
---------------------------------------------------------------------------
local modules = {}
function HP:NewModule(name)
	local m = { name = name }
	self[name] = m
	modules[#modules + 1] = m
	return m
end

HP.options = {}
-- opt = { path=, label=, section=, type="toggle"|"choice"|"range", values={ {value,label},... }, min, max, step, desc }
function HP:RegisterOption(opt)
	self.options[#self.options + 1] = opt
end

---------------------------------------------------------------------------
-- CVar helper that remembers what the player had, so everything is reversible.
---------------------------------------------------------------------------
function HP:SetCVarTracked(name, value)
	local ok, current = pcall(GetCVar, name)
	if not ok or current == nil then return false end
	self.db.cvarBackup = self.db.cvarBackup or {}
	if self.db.cvarBackup[name] == nil then self.db.cvarBackup[name] = current end
	return pcall(SetCVar, name, tostring(value))
end

function HP:RestoreCVars()
	if not self.db.cvarBackup then return end
	for name, value in pairs(self.db.cvarBackup) do pcall(SetCVar, name, value) end
	self.db.cvarBackup = nil
end

---------------------------------------------------------------------------
-- Boot
---------------------------------------------------------------------------
HP:On("ADDON_LOADED", function(name)
	if name ~= ADDON then return end
	HearthpadDB = HearthpadDB or {}
	HP.db = copyDefaults(HP.defaults, HearthpadDB)
end)

HP:On("PLAYER_LOGIN", function()
	local w, h = 0, 0
	if GetPhysicalScreenSize then w, h = GetPhysicalScreenSize() end
	-- Both Deck models (LCD and OLED) run at 1280x800; /run HearthpadDB.forceDeck=true overrides.
	HP.isSteamDeck = (w == 1280 and h == 800) or HP.db.forceDeck == true
	for _, m in ipairs(modules) do
		if m.Init then
			local ok, err = pcall(m.Init, m)
			if not ok then geterrorhandler()(("Hearthpad %s: %s"):format(m.name, tostring(err))) end
		end
	end
	HP:Fire("HP_READY")
end)

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------
SLASH_HEARTHPAD1, SLASH_HEARTHPAD2 = "/hearthpad", "/hp"
SlashCmdList.HEARTHPAD = function(msg)
	local cmd, rest = (msg or ""):lower():match("^(%S*)%s*(.-)$")
	if cmd == "" or cmd == "hub" then HP.Hub:Toggle()
	elseif cmd == "controls" then HP.Onboarding:ShowControls()
	elseif cmd == "preset" then HP.Onboarding:ApplyDeckPreset() HP:Print("Steam Deck preset applied.")
	elseif cmd == "welcome" then HP.Onboarding:ShowWelcome()
	elseif cmd == "camera" then HP.Explore:CycleCamera()
	elseif cmd == "restore" then
		HP:AfterCombat("restore", function() HP.Bindings:Clear() HP:RestoreCVars() end)
		HP:Set("controls.enabled", false)
		HP:Print("Bindings and changed settings restored to what you had before Hearthpad.")
	elseif cmd == "debug" then HP.db.debug = not HP.db.debug HP:Print("debug", HP.db.debug and "on" or "off")
	elseif cmd == "reset" then HearthpadDB = nil ReloadUI()
	else
		HP:Print("/hp — open Hub · /hp controls · /hp preset · /hp camera · /hp restore · /hp reset")
	end
end

-- Key binding labels (Bindings.xml)
BINDING_HEADER_HEARTHPAD = "Hearthpad"
BINDING_NAME_HEARTHPAD_HUB = "Open Hearthpad Hub"
BINDING_NAME_HEARTHPAD_CAMERA = "Cycle camera mode"
