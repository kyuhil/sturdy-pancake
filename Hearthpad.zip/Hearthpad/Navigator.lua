-- Hearthpad: controller navigation for Blizzard's own windows.
-- When a panel opens (bags, vendor, character, talents, mail, map...) the D-pad snaps a
-- gold focus ring between its real buttons. A presses the focused button through a secure
-- proxy (so protected things like using a bag item work), X right-clicks, B closes,
-- L1/R1 switch tabs, Y jumps between open windows and the right stick scrolls lists.
-- Out of combat only; in combat the buttons go straight back to fighting.
local _, HP = ...
local N = HP:NewModule("Navigator")
local T = HP.Theme
local I

N.panels = {
	"GameMenuFrame", "CharacterFrame", "ContainerFrameCombinedBags",
	"ContainerFrame1", "ContainerFrame2", "ContainerFrame3", "ContainerFrame4", "ContainerFrame5", "ContainerFrame6",
	"BankFrame", "MerchantFrame", "MailFrame", "OpenMailFrame", "TradeFrame", "LootFrame",
	"GossipFrame", "QuestFrame", "ClassTrainerFrame", "TaxiFrame", "FlightMapFrame",
	"WorldMapFrame", "PlayerSpellsFrame", "SpellBookFrame", "PlayerTalentFrame", "ClassTalentFrame", "TalentFrame",
	"FriendsFrame", "PVEFrame", "CommunitiesFrame", "GuildFrame", "AuctionHouseFrame", "ProfessionsFrame",
	"TradeSkillFrame", "CraftFrame", "CollectionsJournal", "EncounterJournal", "AchievementFrame",
	"DressUpFrame", "InspectFrame", "ItemTextFrame", "PetStableFrame", "GuildBankFrame", "AddonList",
	"StaticPopup1", "StaticPopup2", "StaticPopup3", "StaticPopup4",
}

local hooked, open = {}, {}
local nodes, focus, lastX, lastY = {}, nil, nil, nil
local ring
local ctx = { name = "navigator", useClickProxy = true, passthrough = { PADBACK = true } }

---------------------------------------------------------------------------
-- Geometry helpers
---------------------------------------------------------------------------
local function center(f)
	local ok, x, y = pcall(f.GetCenter, f)
	if not ok or not x then return nil end
	local s = f:GetEffectiveScale()
	return x * s, y * s
end

local function insideClipping(f, stopAt)
	local cx, cy = center(f)
	if not cx then return false end
	local p = f:GetParent()
	while p and p ~= UIParent do
		if p.DoesClipChildren and p:DoesClipChildren() then
			local l, b, w, h = p:GetRect()
			if l then
				local s = p:GetEffectiveScale()
				if cx < l * s or cx > (l + w) * s or cy < b * s or cy > (b + h) * s then return false end
			end
		end
		if p == stopAt then break end
		p = p:GetParent()
	end
	return true
end

local function isNode(f)
	if f.IsForbidden and f:IsForbidden() then return false end
	if not f:IsVisible() then return false end
	if f:GetEffectiveAlpha() < 0.05 then return false end
	local w, h = f:GetSize()
	if (w or 0) < 8 or (h or 0) < 8 then return false end
	local mouse = (f.IsMouseClickEnabled and f:IsMouseClickEnabled()) or (f.IsMouseEnabled and f:IsMouseEnabled())
	if not mouse then return false end
	local kind = f:GetObjectType()
	if kind == "Button" or kind == "CheckButton" then return true end
	if f:HasScript("OnMouseDown") and f:GetScript("OnMouseDown") then return true end
	if f:HasScript("OnMouseUp") and f:GetScript("OnMouseUp") then return true end
	return false
end

local function collect(frame, panel, out, depth)
	if depth > 14 then return end
	local children = { frame:GetChildren() }
	for i = 1, #children do
		local c = children[i]
		local ok, yes = pcall(isNode, c)
		if ok and yes and insideClipping(c, panel) then out[#out + 1] = c end
		local okV, visible = pcall(c.IsVisible, c)
		if okV and visible then collect(c, panel, out, depth + 1) end
	end
end

---------------------------------------------------------------------------
-- Focus ring
---------------------------------------------------------------------------
local function buildRing()
	ring = CreateFrame("Frame", "HearthpadFocusRing", UIParent)
	ring:SetFrameStrata("TOOLTIP")
	ring:EnableMouse(false)
	local c = T.color.accent
	local function edge(p1, p2, horiz)
		local t = ring:CreateTexture(nil, "OVERLAY")
		t:SetColorTexture(c[1], c[2], c[3], 1)
		t:SetPoint(p1) t:SetPoint(p2)
		if horiz then t:SetHeight(2) else t:SetWidth(2) end
	end
	edge("TOPLEFT", "TOPRIGHT", true) edge("BOTTOMLEFT", "BOTTOMRIGHT", true)
	edge("TOPLEFT", "BOTTOMLEFT") edge("TOPRIGHT", "BOTTOMRIGHT")
	local glow = ring:CreateTexture(nil, "BACKGROUND")
	glow:SetPoint("TOPLEFT", -4, 4) glow:SetPoint("BOTTOMRIGHT", 4, -4)
	glow:SetColorTexture(c[1], c[2], c[3], 0.12)
	local pulse = ring:CreateAnimationGroup()
	pulse:SetLooping("BOUNCE")
	local a = pulse:CreateAnimation("Alpha")
	a:SetFromAlpha(1) a:SetToAlpha(0.55) a:SetDuration(0.7)
	pulse:Play()

	ring.hints = T.HintBar(ring, nil, 22)
	ring.hints:SetPoint("TOPLEFT", ring, "BOTTOMLEFT", 0, -6)
	ring:Hide()
end

local function blur()
	if focus and HP.db.nav.tooltips then
		local leave = focus:GetScript("OnLeave")
		if leave then pcall(leave, focus) end
	end
	GameTooltip:Hide()
end

function N:Focus(node)
	if not node then return end
	if focus ~= node then blur() end
	focus = node
	lastX, lastY = center(node)
	ring:ClearAllPoints()
	ring:SetPoint("TOPLEFT", node, "TOPLEFT", -3, 3)
	ring:SetPoint("BOTTOMRIGHT", node, "BOTTOMRIGHT", 3, -3)
	ring:Show()
	I:SetClickTarget(node)
	if HP.db.nav.tooltips then
		local enter = node:GetScript("OnEnter")
		if enter then pcall(enter, node) end
	end
	-- Keep the hint row out of the way when a tooltip is showing
	ring.hints:SetShown(not GameTooltip:IsShown())
end

---------------------------------------------------------------------------
-- Scan & move
---------------------------------------------------------------------------
function N:Scan()
	wipe(nodes)
	for _, panel in ipairs(open) do
		if panel:IsVisible() then collect(panel, panel, nodes, 0) end
	end
	if #nodes == 0 then ring:Hide() return end
	for _, n in ipairs(nodes) do if n == focus then return end end
	-- focus vanished: snap to the node nearest to where it was, else top-left of top panel
	local best, bestD
	for _, n in ipairs(nodes) do
		local x, y = center(n)
		if x then
			local d
			if lastX then d = (x - lastX) ^ 2 + (y - lastY) ^ 2 else d = x - y * 2 end
			if not bestD or d < bestD then best, bestD = n, d end
		end
	end
	self:Focus(best)
end

local DIRS = {
	PADDUP = function(dx, dy) return dy, dx end,
	PADDDOWN = function(dx, dy) return -dy, dx end,
	PADDRIGHT = function(dx, dy) return dx, dy end,
	PADDLEFT = function(dx, dy) return -dx, dy end,
}

function N:Move(key)
	if not focus then self:Scan() return end
	local cx, cy = center(focus)
	if not cx then self:Scan() return end
	local proj = DIRS[key]
	local best, bestScore
	for _, n in ipairs(nodes) do
		if n ~= focus then
			local x, y = center(n)
			if x then
				local primary, secondary = proj(x - cx, y - cy)
				if primary > 4 then
					local score = primary + math.abs(secondary) * 2.4
					if not bestScore or score < bestScore then best, bestScore = n, score end
				end
			end
		end
	end
	if best then
		self:Focus(best)
		HP.Gamepad:Rumble("tick")
	end
end

---------------------------------------------------------------------------
-- Panel actions
---------------------------------------------------------------------------
local function closePanel(p)
	if not p then return end
	local name = p:GetName() or ""
	if name:find("^StaticPopup") then
		local cancel = p.button2 or _G[name .. "Button2"]
		if cancel and cancel:IsShown() then cancel:Click() return end
	end
	local close = p.CloseButton or _G[name .. "CloseButton"] or (p.BorderFrame and p.BorderFrame.CloseButton)
	if close and close:IsShown() then pcall(close.Click, close) return end
	if not pcall(HideUIPanel, p) or p:IsShown() then pcall(p.Hide, p) end
end

local function tabsOf(p)
	local tabs = {}
	local name = p:GetName()
	if p.Tabs then for _, t in ipairs(p.Tabs) do tabs[#tabs + 1] = t end end
	if #tabs == 0 and p.TabSystem and p.TabSystem.tabs then
		for _, t in ipairs(p.TabSystem.tabs) do tabs[#tabs + 1] = t end
	end
	if #tabs == 0 and name then
		for i = 1, 12 do
			local t = _G[name .. "Tab" .. i]
			if not t then break end
			tabs[#tabs + 1] = t
		end
	end
	local shown = {}
	for _, t in ipairs(tabs) do if t:IsShown() then shown[#shown + 1] = t end end
	table.sort(shown, function(a, b) return (a:GetLeft() or 0) < (b:GetLeft() or 0) end)
	return shown
end

local function switchTab(step)
	local p = open[1]
	if not p then return end
	local tabs = tabsOf(p)
	if #tabs < 2 then return end
	local cur = 1
	local selected = p.selectedTab or (PanelTemplates_GetSelectedTab and PanelTemplates_GetSelectedTab(p))
	for i, t in ipairs(tabs) do
		if (selected and t:GetID() == selected) or (t.IsEnabled and not t:IsEnabled()) or t.isSelected then cur = i end
	end
	local nextTab = tabs[(cur - 1 + step) % #tabs + 1]
	pcall(nextTab.Click, nextTab)
	HP.Gamepad:Rumble("tick")
	C_Timer.After(0.05, function() focus = nil N:Scan() end)
end

local function cyclePanel()
	if #open < 2 then return end
	table.insert(open, table.remove(open, 1))
	focus, lastX, lastY = nil, nil, nil
	-- aim for the new front window's top-left corner
	local p = open[1]
	if p:GetLeft() then
		lastX, lastY = p:GetLeft() * p:GetEffectiveScale(), p:GetTop() * p:GetEffectiveScale()
	end
	N:Scan()
end

function ctx:OnKey(key)
	if DIRS[key] then N:Move(key)
	elseif key == "PAD2" then closePanel(open[1])
	elseif key == "PAD4" then cyclePanel()
	elseif key == "PADLSHOULDER" then switchTab(-1)
	elseif key == "PADRSHOULDER" then switchTab(1)
	elseif key == "PADFORWARD" then HP.Hub:Toggle()
	end
end

function ctx:OnProxyClick()
	HP.Gamepad:Rumble("tick")
	C_Timer.After(0.06, function() N:Scan() end)
end

function ctx:OnCombat()
	blur()
	ring:Hide()
end

---------------------------------------------------------------------------
-- Activation
---------------------------------------------------------------------------
function N:Activate()
	if not HP.db.nav.enabled or #open == 0 then return end
	if InCombatLockdown() then
		HP:AfterCombat("nav-activate", function() N:Activate() end)
		return
	end
	if not I:IsActive(ctx) then I:Push(ctx) end
	ring.hints:SetHints({ { "PAD1", "Select" }, { "PAD3", "Use / Alt" }, { "PAD2", "Close" },
		#open > 1 and { "PAD4", "Next window" } or nil })
	self:Scan()
end

function N:Deactivate()
	blur()
	ring:Hide()
	focus, lastX, lastY = nil, nil, nil
	I:Pop(ctx)
end

local function owned(p)
	return HP.Dialogue and HP.Dialogue.Owns and HP.Dialogue:Owns(p)
end

function N:PanelShown(p)
	for i = #open, 1, -1 do if open[i] == p then table.remove(open, i) end end
	table.insert(open, 1, p)
	C_Timer.After(0, function()
		if owned(p) then
			for i = #open, 1, -1 do if open[i] == p then table.remove(open, i) end end
			if #open == 0 then N:Deactivate() end
			return
		end
		focus = nil
		N:Activate()
	end)
end

function N:PanelHidden(p)
	for i = #open, 1, -1 do if open[i] == p then table.remove(open, i) end end
	if #open == 0 then N:Deactivate() else focus = nil C_Timer.After(0, function() N:Scan() end) end
end

local function hookPanel(name)
	if hooked[name] then return end
	local f = _G[name]
	if not f or not f.HookScript then return end
	hooked[name] = true
	f:HookScript("OnShow", function(self) N:PanelShown(self) end)
	f:HookScript("OnHide", function(self) N:PanelHidden(self) end)
	if f:IsShown() then N:PanelShown(f) end
end

local function hookAll() for _, name in ipairs(N.panels) do hookPanel(name) end end

-- Right stick scrolls whatever list the focused button lives in.
local lastScroll = 0
local function scrollTick(sticks)
	if not I:IsActive(ctx) or InCombatLockdown() or not focus then return end
	local y = sticks[2] and sticks[2].y or 0
	if math.abs(y) < 0.45 or GetTime() - lastScroll < (math.abs(y) > 0.9 and 0.05 or 0.12) then return end
	lastScroll = GetTime()
	local p = focus
	while p and p ~= UIParent do
		local wheel = p:HasScript("OnMouseWheel") and p:GetScript("OnMouseWheel")
		if wheel then
			pcall(wheel, p, y > 0 and 1 or -1)
			C_Timer.After(0.03, function() N:Scan() end)
			return
		end
		p = p:GetParent()
	end
end

function N:Init()
	I = HP.Input
	HP:RegisterOption({ path = "nav.enabled", label = "D-pad navigation in windows", section = "Menus", type = "toggle",
		desc = "Off returns windows to Blizzard's free gamepad cursor." })
	HP:RegisterOption({ path = "nav.tooltips", label = "Show tooltips on focus", section = "Menus", type = "toggle" })

	buildRing()
	hookAll()
	HP:On("ADDON_LOADED", hookAll) -- load-on-demand windows (talents, auction house, professions...)
	HP:On("HP_STICKS", scrollTick)
	HP:On("HP_SETTING_CHANGED", function(path, value)
		if path == "nav.enabled" then
			if value then N:Activate() else N:Deactivate() end
		end
	end)
	-- Content inside windows changes constantly (loot rolls, scrolling lists); keep nodes fresh.
	C_Timer.NewTicker(0.4, function()
		if I:IsActive(ctx) and not InCombatLockdown() then N:Scan() end
	end)
end
